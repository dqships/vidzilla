"use strict";
(() => {
  // src/content/eme-main.ts
  var proto = HTMLMediaElement.prototype;
  var original = proto.setMediaKeys;
  if (original) {
    proto.setMediaKeys = function(keys) {
      if (keys) {
        try {
          const system = keys.keySystem ?? keySystems.get(keys) ?? "unknown";
          window.postMessage({ __vidzilla: "eme", keySystem: system }, "*");
        } catch {
        }
      }
      return original.call(this, keys);
    };
  }
  window.addEventListener(
    "encrypted",
    (e) => {
      if (e.target instanceof HTMLMediaElement) window.postMessage({ __vidzilla: "eme", keySystem: "encrypted" }, "*");
    },
    true
  );
  var keySystems = /* @__PURE__ */ new WeakMap();
  var request = navigator.requestMediaKeySystemAccess?.bind(navigator);
  if (request) {
    navigator.requestMediaKeySystemAccess = async (keySystem, configs) => {
      const access = await request(keySystem, configs);
      const create = access.createMediaKeys.bind(access);
      access.createMediaKeys = async () => {
        const keys = await create();
        keySystems.set(keys, access.keySystem);
        return keys;
      };
      return access;
    };
  }
})();
//# sourceMappingURL=eme-main.js.map
