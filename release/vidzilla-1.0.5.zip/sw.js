// src/shared/hash.ts
function hash53(str, seed = 0) {
  let h1 = 3735928559 ^ seed;
  let h2 = 1103547991 ^ seed;
  for (let i = 0; i < str.length; i++) {
    const ch = str.charCodeAt(i);
    h1 = Math.imul(h1 ^ ch, 2654435761);
    h2 = Math.imul(h2 ^ ch, 1597334677);
  }
  h1 = Math.imul(h1 ^ h1 >>> 16, 2246822507) ^ Math.imul(h2 ^ h2 >>> 13, 3266489909);
  h2 = Math.imul(h2 ^ h2 >>> 16, 2246822507) ^ Math.imul(h1 ^ h1 >>> 13, 3266489909);
  return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(36);
}

// src/shared/titles.ts
var SEPARATOR = /\s+[|\-–—/·]\s+(?=[^|\-–—/·]*$)/;
var MAX_SITE_WORDS = 3;
function hostLabels(host) {
  const labels = host.toLowerCase().replace(/^www\./, "").split(".");
  return labels.slice(0, -1).filter((l) => l.length > 1);
}
function isSiteName(segment, src) {
  const s = segment.trim().toLowerCase();
  if (!s || s.split(/\s+/).length > MAX_SITE_WORDS) return false;
  if (src.siteName && s === src.siteName.trim().toLowerCase()) return true;
  const words = s.split(/[\s.]+/);
  return hostLabels(src.host).some((l) => words.includes(l)) || s.length === 1 && hostLabels(src.host).includes("x");
}
function strip(title, src) {
  let t = title.replace(/^\(\d+\+?\)\s+/, "").trim();
  const x = /^(.+?) on X: [“"](.*)[”"](?:\s*\/\s*X)?$/s.exec(t);
  if (x) return `${x[1]}: ${x[2].replace(/\s+/g, " ").trim()}`;
  for (let i = 0; i < 2; i++) {
    const m = SEPARATOR.exec(t);
    if (!m || !isSiteName(t.slice(m.index + m[0].length), src)) break;
    t = t.slice(0, m.index).trim();
  }
  const on = /\s+on\s+(\S+)$/.exec(t);
  if (on && on.index > 0 && isSiteName(on[1], src)) t = t.slice(0, on.index).trim();
  return t;
}
function cleanTitle(src) {
  const doc = src.docTitle?.trim() ? strip(src.docTitle, src) : "";
  if (doc && !isSiteName(doc, src)) return doc;
  const og = src.ogTitle?.trim() ? strip(src.ogTitle, src) : "";
  return og || src.docTitle?.trim() || void 0;
}

// src/sw/classify.ts
var MIN_DIRECT_BYTES = 500 * 1024;
var MIME_EXT = {
  "video/mp4": "mp4",
  "video/x-m4v": "m4v",
  "video/webm": "webm",
  "video/x-matroska": "mkv",
  "video/quicktime": "mov",
  "video/mpeg": "mpg",
  "video/ogg": "ogv",
  "video/x-flv": "flv",
  "video/3gpp": "3gp",
  "video/x-msvideo": "avi",
  "audio/mp4": "m4a",
  "audio/x-m4a": "m4a",
  "audio/mpeg": "mp3",
  "audio/mp3": "mp3",
  "audio/webm": "weba",
  "audio/ogg": "ogg",
  "audio/flac": "flac",
  "audio/x-flac": "flac",
  "audio/wav": "wav",
  "audio/x-wav": "wav",
  "audio/aac": "aac"
};
var MEDIA_EXTS = /* @__PURE__ */ new Set([
  "mp4",
  "m4v",
  "webm",
  "mkv",
  "mov",
  "mpg",
  "mpeg",
  "ogv",
  "flv",
  "3gp",
  "avi",
  "m4a",
  "mp3",
  "weba",
  "ogg",
  "oga",
  "opus",
  "flac",
  "wav",
  "aac"
]);
var AD_URL = /(^|[./])(doubleclick\.net|googlesyndication\.com|2mdn\.net|imasdk\.googleapis\.com|adswizz\.com|criteo\.net|adnxs\.com|adnxs-simple\.com)\/|\/source\/dclk_video_ads\//i;
var SEGMENT_PATH = /\.(ts|m4s|m2ts|cmfv|cmfa)$/i;
function header(info, name) {
  const lower = name.toLowerCase();
  return info.responseHeaders.find((h) => h.name.toLowerCase() === lower)?.value;
}
function pathExt(pathname) {
  const m = /\.([a-z0-9]{1,5})$/i.exec(pathname);
  return m?.[1]?.toLowerCase();
}
function dispositionFilename(value) {
  if (!value) return void 0;
  const star = /filename\*\s*=\s*(?:[\w-]+)?'[^']*'([^;]+)/i.exec(value);
  if (star?.[1]) {
    try {
      return decodeURIComponent(star[1].trim());
    } catch {
    }
  }
  const plain = /filename\s*=\s*("([^"]*)"|[^;]+)/i.exec(value);
  const name = plain?.[2] ?? plain?.[1];
  return name?.trim() || void 0;
}
function totalSize(info) {
  const range = header(info, "content-range");
  const total = range && /\/(\d+)\s*$/.exec(range)?.[1];
  if (total) return Number(total);
  if (info.statusCode === 200) {
    const len = Number(header(info, "content-length"));
    if (Number.isFinite(len) && len > 0) return len;
  }
  return void 0;
}
function classify(info) {
  if (info.statusCode < 200 || info.statusCode >= 300) return null;
  if (info.initiator?.startsWith("chrome-extension://")) return null;
  let url;
  try {
    url = new URL(info.url);
  } catch {
    return null;
  }
  if (url.protocol !== "http:" && url.protocol !== "https:") return null;
  if (AD_URL.test(url.hostname + "/" + url.pathname)) return null;
  const mime = (header(info, "content-type") ?? "").split(";")[0].trim().toLowerCase();
  const ext = pathExt(url.pathname);
  const href = url.pathname + url.search;
  if (mime.includes("mpegurl") || ext === "m3u8") {
    return { type: "hls", mime, ext: "mp4", supportsRanges: false };
  }
  if (mime.includes("dash+xml") || ext === "mpd") {
    return { type: "dash", mime, ext: "mp4", supportsRanges: false };
  }
  if (SEGMENT_PATH.test(url.pathname) || mime === "video/mp2t" || mime === "video/iso.segment") return null;
  if (mime.startsWith("image/") || mime.startsWith("text/") || mime.includes("json") || mime.includes("javascript")) {
    return null;
  }
  const serverFilename = dispositionFilename(header(info, "content-disposition"));
  const dispositionExt = serverFilename ? pathExt(serverFilename) : void 0;
  const looksLikeMedia = info.type === "media" || mime.startsWith("video/") || mime.startsWith("audio/") || ext !== void 0 && MEDIA_EXTS.has(ext) || dispositionExt !== void 0 && MEDIA_EXTS.has(dispositionExt);
  if (!looksLikeMedia) return null;
  if (/[?&](range|bytestart)=/i.test(href)) return null;
  if (/\/(range\/\d|begin\/\d+\/len\/\d)/i.test(url.pathname)) return null;
  const sizeBytes = totalSize(info);
  if (sizeBytes !== void 0 && sizeBytes < MIN_DIRECT_BYTES) return null;
  const chosenExt = (ext && MEDIA_EXTS.has(ext) ? ext : void 0) ?? (dispositionExt && MEDIA_EXTS.has(dispositionExt) ? dispositionExt : void 0) ?? MIME_EXT[mime] ?? "mp4";
  const acceptRanges = header(info, "accept-ranges")?.toLowerCase();
  return {
    type: "http",
    mime,
    ext: chosenExt,
    sizeBytes,
    supportsRanges: acceptRanges === "bytes" || header(info, "content-range") !== void 0,
    serverFilename
  };
}

// src/shared/messages.ts
var storageKeys = {
  tab: (tabId) => `tab:${tabId}`,
  jobs: "jobs",
  settings: "settings",
  history: "history",
  asks: "asks",
  /** House ad schedule state (shared/ads.ts AdState). */
  ads: "ads",
  /** The ad list last fetched from the website, with when. */
  adFeed: "adFeed",
  /** The ad-free license as the website last answered (shared/license.ts). */
  license: "license",
  /** This install's random ID, in chrome.storage.sync. */
  installId: "installId",
  /** When a copy on this Chrome profile last saw a paid license (ms), in chrome.storage.sync. */
  paidAt: "paidAt",
  /** The checkout that confirmed this profile's purchase, in chrome.storage.sync: sent with each check. */
  paidSession: "paidSession",
  /** What removing the ads costs this install, as the website last said (shared/license.ts). */
  prices: "prices",
  /** When this install's first save was reported to PostHog as `activated` (ms), in chrome.storage.sync (sw/analytics.ts). */
  activatedAt: "activatedAt",
  /** When this install was reported to PostHog as `signed_up` (ms), in chrome.storage.sync (sw/analytics.ts). */
  signedUpAt: "signedUpAt",
  /** True while a fresh install's `signed_up` still has to reach PostHog, in chrome.storage.local (sw/analytics.ts). */
  signUpPending: "signUpPending"
};

// src/shared/naming.ts
function savedExt(item, variant) {
  return variant?.webm ? "webm" : variant?.audioOnly ? "m4a" : item.ext;
}
var RESERVED_WINDOWS = /^(con|prn|aux|nul|com[1-9]|lpt[1-9])$/i;
var MAX_BYTES = 200;
function siteLabel(url) {
  let host;
  try {
    host = new URL(url).hostname;
  } catch {
    return "";
  }
  if (/^[\d.]+$/.test(host) || host.includes(":") || host.startsWith("[")) return host;
  const parts = host.replace(/^www\d*\./, "").split(".");
  if (parts.length === 1) return parts[0] ?? "";
  const secondLevel = parts.at(-2) ?? "";
  const hasCompoundSuffix = parts.length >= 3 && (parts.at(-1) ?? "").length === 2 && /^(co|com|org|net|gov|ac|edu|ne|or)$/.test(secondLevel);
  return (hasCompoundSuffix ? parts.at(-3) : secondLevel) ?? "";
}
function stripExt(name) {
  return name.replace(/\.[a-z0-9]{1,5}$/i, "");
}
function nameFromUrl(url) {
  try {
    const last = new URL(url).pathname.split("/").filter(Boolean).at(-1) ?? "";
    return stripExt(decodeURIComponent(last));
  } catch {
    return "";
  }
}
function isoDate(d) {
  const pad = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}
function expandTemplate(template, vars) {
  return template.replace(/([\s_-]*)%([a-z]+)/gi, (whole, sep, key) => {
    const value = vars[key.toLowerCase()];
    if (value === void 0) return whole;
    return value === "" ? "" : sep + value;
  }).replace(/^[\s_-]+|[\s_-]+$/g, "");
}
function truncateBytes(s, maxBytes) {
  const enc = new TextEncoder();
  if (enc.encode(s).length <= maxBytes) return s;
  let out = "";
  for (const ch of s) {
    if (enc.encode(out + ch).length > maxBytes) break;
    out += ch;
  }
  return out;
}
function sanitizeFilename(raw, maxLength = 80) {
  let s = raw.normalize("NFC");
  s = s.replace(/[\u0000-\u001f\u007f]/g, " ");
  s = s.replace(/[<>:"/\\|?*]/g, " ");
  s = s.replace(/\s+/g, " ").replace(/-{2,}/g, "-");
  s = s.replace(/^[\s.]+/, "");
  s = Array.from(s).slice(0, maxLength).join("");
  s = truncateBytes(s, MAX_BYTES);
  s = s.replace(/[\s.]+$/, "");
  if (RESERVED_WINDOWS.test(s)) s += "_";
  return s || "untitled";
}
function buildFilename(input) {
  const title = input.title?.trim() || (input.serverFilename ? stripExt(input.serverFilename) : "") || nameFromUrl(input.mediaUrl);
  const base = expandTemplate(input.template, {
    title,
    hostname: siteLabel(input.pageUrl),
    date: isoDate(input.now ?? /* @__PURE__ */ new Date())
  });
  return `${sanitizeFilename(base, input.maxLength)}.${input.ext}`;
}
function asciiFilename(path) {
  return path.split("/").map((part) => {
    const dot = part.lastIndexOf(".");
    const [base, ext] = dot > 0 ? [part.slice(0, dot), part.slice(dot)] : [part, ""];
    const plain = base.normalize("NFKD").replace(/[\u2010-\u2015]/g, "-").replace(/[^\x20-\x7e]/g, "").replace(/\s+/g, " ").trim();
    return (plain || "video") + ext;
  }).join("/");
}
var MIME_BY_EXT = {
  mp4: "video/mp4",
  m4v: "video/x-m4v",
  webm: "video/webm",
  mkv: "video/x-matroska",
  mov: "video/quicktime",
  mpg: "video/mpeg",
  mpeg: "video/mpeg",
  ogv: "video/ogg",
  flv: "video/x-flv",
  "3gp": "video/3gpp",
  avi: "video/x-msvideo",
  ts: "video/mp2t",
  m4a: "audio/mp4",
  mp3: "audio/mpeg",
  weba: "audio/webm",
  ogg: "audio/ogg",
  oga: "audio/ogg",
  opus: "audio/ogg",
  flac: "audio/flac",
  wav: "audio/wav",
  aac: "audio/aac"
};
function mimeForFilename(name) {
  const ext = /\.([a-z0-9]{1,5})$/i.exec(name)?.[1]?.toLowerCase();
  return ext && MIME_BY_EXT[ext] || "application/octet-stream";
}

// src/shared/history.ts
var MAX_HISTORY = 300;
function withEntry(list2, entry) {
  return [entry, ...list2.filter((e) => e.id !== entry.id)].slice(0, MAX_HISTORY);
}
async function loadHistory() {
  return (await chrome.storage.local.get(storageKeys.history))[storageKeys.history] ?? [];
}
var pending = Promise.resolve();
function addHistory(entry) {
  const next = pending.then(async () => {
    await chrome.storage.local.set({ [storageKeys.history]: withEntry(await loadHistory(), entry) });
  });
  pending = next.catch(() => {
  });
  return next;
}

// src/shared/settings.ts
var defaultSettings = {
  template: "%title",
  maxLength: 80,
  subfolder: "",
  saveAs: false,
  sidePanel: false
};
async function loadSettings() {
  const stored = (await chrome.storage.local.get(storageKeys.settings))[storageKeys.settings];
  return { ...defaultSettings, ...stored };
}

// src/shared/hls.ts
function parseAttributes(s) {
  const out = {};
  const re = /([A-Z0-9-]+)=("[^"]*"|[^,]*)/g;
  let m;
  while (m = re.exec(s)) {
    const raw = m[2];
    out[m[1]] = raw.startsWith('"') ? raw.slice(1, -1) : raw;
  }
  return out;
}
function resolve(uri, base) {
  try {
    return new URL(uri, base).href;
  } catch {
    return uri;
  }
}
var num = (v) => v === void 0 || v === "" || Number.isNaN(Number(v)) ? void 0 : Number(v);
function parseM3u8(text2, baseUrl) {
  const lines = text2.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
  if (!lines[0]?.startsWith("#EXTM3U")) throw new Error("Not an M3U8 playlist");
  const variants = [];
  const renditions = [];
  const sessionKeys = [];
  const segments = [];
  const otherUris = [];
  const keys = [];
  let duration = 0;
  let endList = false;
  let playlistType;
  let pendingVariant;
  for (const line of lines) {
    if (!line.startsWith("#")) {
      if (pendingVariant) {
        variants.push({ ...pendingVariant, uri: resolve(line, baseUrl) });
        pendingVariant = void 0;
      } else {
        segments.push(resolve(line, baseUrl));
      }
      continue;
    }
    const colon = line.indexOf(":");
    const tag = colon < 0 ? line : line.slice(0, colon);
    const value = colon < 0 ? "" : line.slice(colon + 1);
    switch (tag) {
      case "#EXT-X-STREAM-INF": {
        const a = parseAttributes(value);
        const [w, h] = (a.RESOLUTION ?? "").split("x").map(Number);
        pendingVariant = {
          uri: "",
          bandwidth: num(a.BANDWIDTH),
          averageBandwidth: num(a["AVERAGE-BANDWIDTH"]),
          width: w || void 0,
          height: h || void 0,
          codecs: a.CODECS,
          frameRate: num(a["FRAME-RATE"]),
          audioGroup: a.AUDIO,
          videoRange: a["VIDEO-RANGE"]
        };
        break;
      }
      case "#EXT-X-MEDIA": {
        const a = parseAttributes(value);
        renditions.push({
          type: a.TYPE,
          groupId: a["GROUP-ID"] ?? "",
          name: a.NAME ?? "",
          language: a.LANGUAGE,
          isDefault: a.DEFAULT === "YES",
          autoselect: a.AUTOSELECT === "YES",
          uri: a.URI ? resolve(a.URI, baseUrl) : void 0
        });
        break;
      }
      case "#EXT-X-SESSION-KEY":
      case "#EXT-X-KEY": {
        const a = parseAttributes(value);
        const key = { method: a.METHOD ?? "NONE", keyFormat: a.KEYFORMAT, uri: a.URI ? resolve(a.URI, baseUrl) : void 0 };
        if (tag === "#EXT-X-SESSION-KEY") sessionKeys.push(key);
        else {
          keys.push(key);
          if (key.uri && !key.uri.startsWith("skd:") && !key.uri.startsWith("data:")) otherUris.push(key.uri);
        }
        break;
      }
      case "#EXT-X-MAP": {
        const uri = parseAttributes(value).URI;
        if (uri) otherUris.push(resolve(uri, baseUrl));
        break;
      }
      case "#EXTINF":
        duration += Number.parseFloat(value) || 0;
        break;
      case "#EXT-X-ENDLIST":
        endList = true;
        break;
      case "#EXT-X-PLAYLIST-TYPE":
        playlistType = value;
        break;
    }
  }
  if (variants.length || renditions.length && !segments.length) {
    return { kind: "master", variants, renditions, sessionKeys };
  }
  return { kind: "media", segments, otherUris, keys, duration, endList, playlistType };
}
var DRM_KEY_FORMATS = [
  "com.apple.streamingkeydelivery",
  // FairPlay
  "com.microsoft.playready",
  "urn:uuid:edef8ba9-79d6-4ace-a3c8-27dcd51d21ed",
  // Widevine
  "urn:uuid:9a04f079-9840-4286-ab92-e65be0885f95"
  // PlayReady
];
function isDrmKey(key) {
  const method = key.method.toUpperCase();
  if (method === "NONE") return false;
  const format = key.keyFormat?.toLowerCase();
  if (format && DRM_KEY_FORMATS.includes(format)) return true;
  if (key.uri?.startsWith("skd:")) return true;
  return method !== "AES-128";
}
function audioFor(master, variant) {
  if (!variant.audioGroup) return void 0;
  const group = master.renditions.filter((r) => r.type === "AUDIO" && r.groupId === variant.audioGroup && r.uri);
  return group.find((r) => r.isDefault) ?? group.find((r) => r.autoselect) ?? group[0];
}
function mbps(bandwidth) {
  return bandwidth >= 1e6 ? `${(bandwidth / 1e6).toFixed(1)} Mbps` : `${Math.round(bandwidth / 1e3)} kbps`;
}
function splitCodecs(codecs) {
  const parts = (codecs ?? "").split(",").map((c) => c.trim()).filter(Boolean);
  const isAudio = (c) => /^(mp4a|ac-3|ec-3|opus|flac|vorbis)/i.test(c);
  const video = parts.filter((c) => !isAudio(c)).join(",");
  const audio = parts.filter(isAudio).join(",");
  return { video: video || void 0, audio: audio || void 0 };
}
function listVariants(master) {
  const seen = /* @__PURE__ */ new Set();
  const out = [];
  const ranked = [...master.variants].sort(
    (a, b) => (b.height ?? 0) - (a.height ?? 0) || (b.bandwidth ?? 0) - (a.bandwidth ?? 0)
  );
  for (const v of ranked) {
    const audio = audioFor(master, v);
    const key = `${v.uri}|${audio?.uri ?? ""}`;
    if (seen.has(key)) continue;
    seen.add(key);
    const { video } = splitCodecs(v.codecs);
    out.push({
      id: "",
      label: "",
      height: v.height,
      width: v.width,
      bandwidth: v.bandwidth,
      codecs: v.codecs,
      url: v.uri,
      audioUrl: audio?.uri,
      audioLanguage: audio?.language,
      audioCodecs: splitCodecs(v.codecs).audio,
      ...video === void 0 && v.codecs && !v.height ? { label: "Audio only" } : {}
    });
  }
  const lightest = [...out].sort((a, b) => (a.bandwidth ?? 0) - (b.bandwidth ?? 0))[0];
  const hasAudioOnly = out.some((v) => v.label === "Audio only");
  if (lightest && !hasAudioOnly && (lightest.audioUrl || codecHasAudio(lightest.codecs))) {
    out.push({
      id: "",
      label: "Audio only",
      audioOnly: true,
      url: lightest.audioUrl ?? lightest.url,
      audioLanguage: lightest.audioLanguage,
      audioCodecs: lightest.audioCodecs
    });
  }
  const ranges = new Map(master.variants.map((m) => [m.uri, m.videoRange]));
  return labelVariants(out, (v) => {
    const range = ranges.get(v.url);
    return range && range !== "SDR" ? ` ${range}` : "";
  });
}
function codecHasAudio(codecs) {
  return !codecs || splitCodecs(codecs).audio !== void 0;
}
function labelVariants(list2, suffix = () => "") {
  const heights = /* @__PURE__ */ new Map();
  for (const v of list2) if (v.height) heights.set(v.height, (heights.get(v.height) ?? 0) + 1);
  list2.forEach((v, i) => {
    v.id = String(i);
    if (v.label) return;
    if (v.height) {
      const shared = (heights.get(v.height) ?? 0) > 1;
      v.label = `${v.height}p${suffix(v)}${shared && v.bandwidth ? ` \xB7 ${mbps(v.bandwidth)}` : ""}`;
    } else if (v.bandwidth) {
      v.label = mbps(v.bandwidth);
    } else {
      v.label = `Quality ${i + 1}`;
    }
  });
  return list2;
}
var quote = (s) => `"${s.replace(/"/g, "%22")}"`;
function singleVariantMaster(variant) {
  const lines = ["#EXTM3U", "#EXT-X-VERSION:3"];
  const attrs = [`BANDWIDTH=${variant.bandwidth ?? 1}`];
  if (variant.width && variant.height) attrs.push(`RESOLUTION=${variant.width}x${variant.height}`);
  if (variant.codecs) attrs.push(`CODECS=${quote(variant.codecs)}`);
  if (variant.audioUrl) {
    const lang = variant.audioLanguage ? `,LANGUAGE=${quote(variant.audioLanguage)}` : "";
    lines.push(`#EXT-X-MEDIA:TYPE=AUDIO,GROUP-ID="aud",NAME="audio"${lang},DEFAULT=YES,AUTOSELECT=YES,URI=${quote(variant.audioUrl)}`);
    attrs.push(`AUDIO="aud"`);
  }
  lines.push(`#EXT-X-STREAM-INF:${attrs.join(",")}`, variant.url, "");
  return lines.join("\n");
}
function dataUrl(playlist) {
  const bytes = new TextEncoder().encode(playlist);
  let bin = "";
  for (const b of bytes) bin += String.fromCharCode(b);
  return `data:application/vnd.apple.mpegurl;base64,${btoa(bin)}`;
}
function listHlsSubtitles(master) {
  return master.renditions.filter((r) => r.type === "SUBTITLES" && r.uri).map((r, i) => ({ id: `hls-${i}`, label: r.name || r.language || `Subtitles ${i + 1}`, lang: r.language, source: { kind: "hls", url: r.uri } }));
}

// src/shared/license.ts
var SITE_ORIGIN = "https://vidzilla.followusai.com";
var UPGRADE_URL = `${SITE_ORIGIN}/upgrade`;
var LICENSE_URL = `${SITE_ORIGIN}/api/license`;
var PRICES_URL = `${SITE_ORIGIN}/api/prices`;
var PRICES_TTL_MS = 6 * 36e5;
var PORTAL_URL = `${SITE_ORIGIN}/api/portal`;
var THANKS_PATH = "/upgrade-thanks";
var LICENSE_TTL_MS = 24 * 36e5;
var PAID_ELSEWHERE_RETRY_MS = 10 * 6e4;
var PAID_ELSEWHERE_GRACE_MS = 24 * 36e5;
var noLicense = { adFree: false, checkedAt: 0 };
async function getInstallId() {
  const stored = (await chrome.storage.sync.get(storageKeys.installId))[storageKeys.installId];
  if (typeof stored === "string" && stored) return stored;
  const id = crypto.randomUUID();
  await chrome.storage.sync.set({ [storageKeys.installId]: id });
  return id;
}
async function loadLicense() {
  const stored = (await chrome.storage.local.get(storageKeys.license))[storageKeys.license];
  return { ...noLicense, ...stored };
}
function parseLicense(json, now) {
  if (!json || typeof json !== "object" || typeof json.adFree !== "boolean") return void 0;
  const j = json;
  if (!j.adFree) return { adFree: false, checkedAt: now };
  const plan = j.plan === "subscription" || j.plan === "yearly" ? "subscription" : j.plan === "lifetime" ? "lifetime" : void 0;
  const until = typeof j.until === "number" ? j.until : null;
  return { adFree: true, plan, until, checkedAt: now };
}
function isAdFree(license, now) {
  return license.adFree && (license.until == null || license.until > now);
}
function shouldCheck(license, paidAt, now) {
  if (license.adFree) return now - license.checkedAt >= LICENSE_TTL_MS;
  return paidAt !== void 0 && (license.checkedAt < paidAt || now - license.checkedAt >= PAID_ELSEWHERE_RETRY_MS);
}
function nextPaidAt(paidAt, adFree, now) {
  if (adFree) return paidAt ?? now;
  return paidAt !== void 0 && now - paidAt < PAID_ELSEWHERE_GRACE_MS ? paidAt : void 0;
}

// src/sw/analytics.ts
var POSTHOG_CAPTURE_URL = "https://us.i.posthog.com/i/v0/e/";
var POSTHOG_KEY = "phc_r4QYEpdtzPfXKeND8mhAEM7stJtxtq8DmUuo9k38iQVx";
var ANALYTICS_SINCE = "1.0.5";
function activatedEvent(installId, version, now) {
  const at = new Date(now).toISOString();
  return {
    api_key: POSTHOG_KEY,
    event: "activated",
    distinct_id: installId,
    timestamp: at,
    properties: {
      product: "vidzilla",
      extension_version: version,
      // No location is looked up from the IP address.
      $geoip_disable: true,
      $set_once: { activated_at: at }
    }
  };
}
function signedUpEvent(installId, version, now) {
  const at = new Date(now).toISOString();
  return {
    api_key: POSTHOG_KEY,
    event: "signed_up",
    distinct_id: installId,
    timestamp: at,
    properties: {
      product: "vidzilla",
      // No account exists: the install is the sign-up.
      method: "extension_install",
      extension_version: version,
      $geoip_disable: true,
      $set_once: { installed_at: at }
    }
  };
}
function olderVersion(a, b) {
  const pa = a.split(".").map(Number);
  const pb = b.split(".").map(Number);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d) return d < 0;
  }
  return false;
}
async function loadActivatedAt() {
  const stored = (await chrome.storage.sync.get(storageKeys.activatedAt))[storageKeys.activatedAt];
  return typeof stored === "number" ? stored : void 0;
}
async function post(body) {
  try {
    const res = await fetch(POSTHOG_CAPTURE_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
      credentials: "omit",
      signal: AbortSignal.timeout(5e3)
    });
    return res.ok;
  } catch {
    return false;
  }
}
var chromeDeps = () => ({
  activatedAt: loadActivatedAt,
  markActivated: (at) => chrome.storage.sync.set({ [storageKeys.activatedAt]: at }),
  installId: getInstallId,
  send: post,
  version: chrome.runtime.getManifest().version,
  now: Date.now
});
async function activateOnce(deps) {
  if (await deps.activatedAt() !== void 0) return false;
  const now = deps.now();
  const sent = await deps.send(activatedEvent(await deps.installId(), deps.version, now));
  if (sent) await deps.markActivated(now);
  return sent;
}
var chromeSignUpDeps = () => ({
  signedUpAt: async () => {
    const stored = (await chrome.storage.sync.get(storageKeys.signedUpAt))[storageKeys.signedUpAt];
    return typeof stored === "number" ? stored : void 0;
  },
  markSignedUp: (at) => chrome.storage.sync.set({ [storageKeys.signedUpAt]: at }),
  signUpPending: async () => (await chrome.storage.local.get(storageKeys.signUpPending))[storageKeys.signUpPending] === true,
  setSignUpPending: (p) => p ? chrome.storage.local.set({ [storageKeys.signUpPending]: true }) : chrome.storage.local.remove(storageKeys.signUpPending),
  installId: getInstallId,
  send: post,
  version: chrome.runtime.getManifest().version,
  now: Date.now
});
async function signUpOnce(deps) {
  if (!await deps.signUpPending()) return false;
  if (await deps.signedUpAt() !== void 0) {
    await deps.setSignUpPending(false);
    return false;
  }
  const now = deps.now();
  const sent = await deps.send(signedUpEvent(await deps.installId(), deps.version, now));
  if (sent) {
    await deps.markSignedUp(now);
    await deps.setSignUpPending(false);
  }
  return sent;
}
var pending2 = Promise.resolve();
function chain(task) {
  const next = pending2.then(task);
  pending2 = next.catch(() => {
  });
  return next;
}
function noteInstalled(deps = chromeSignUpDeps()) {
  return chain(async () => {
    await deps.setSignUpPending(true);
    return signUpOnce(deps);
  });
}
function retrySignUp(deps = chromeSignUpDeps()) {
  return chain(() => signUpOnce(deps));
}
function noteActivated(deps = chromeDeps(), signUp) {
  return chain(async () => {
    try {
      await signUpOnce(signUp ?? chromeSignUpDeps());
    } catch {
    }
    return activateOnce(deps);
  });
}
async function skipActivationIfSavedBefore(previousVersion, savedBefore, deps = chromeDeps()) {
  if (!previousVersion || !olderVersion(previousVersion, ANALYTICS_SINCE) || savedBefore < 1) return false;
  if (await deps.activatedAt() !== void 0) return false;
  await deps.markActivated(deps.now());
  return true;
}

// src/shared/asks.ts
var REVIEW_FIRST = 3;
var SHARE_FIRST = 6;
var initialAskState = {
  saved: 0,
  reviewAsks: 0,
  reviewAt: REVIEW_FIRST,
  reviewDone: false,
  shareAt: SHARE_FIRST,
  shareDone: false
};
function afterSave(state) {
  const next = { ...state, saved: state.saved + 1 };
  if (next.due) return next;
  if (!next.reviewDone && next.saved >= next.reviewAt) return { ...next, due: "review", reviewAsks: next.reviewAsks + 1 };
  if (!next.shareDone && next.saved >= next.shareAt) return { ...next, due: "share" };
  return next;
}
function quietSave(state) {
  return { ...state, saved: state.saved + 1 };
}
async function loadAsks() {
  const stored = (await chrome.storage.local.get(storageKeys.asks))[storageKeys.asks];
  return { ...initialAskState, ...stored };
}
var pending3 = Promise.resolve();
function updateAsks(change) {
  const next = pending3.then(async () => {
    const state = change(await loadAsks());
    await chrome.storage.local.set({ [storageKeys.asks]: state });
    return state;
  });
  pending3 = next.catch(() => {
  });
  return next;
}

// src/shared/ads.ts
var ADS_FEED_URL = "https://vidzilla.followusai.com/ads.json";
var defaultSchedule = { firstAfter: 5, every: 4, minHours: 6, seconds: 15 };
var emptyAdState = { saved: 0, sinceAd: 0, shownAt: 0, next: 0, adFree: false };
var LIMITS = { id: 40, name: 40, line: 120, cta: 32, url: 500 };
function text(value, max) {
  if (typeof value !== "string") return void 0;
  const clean = value.replace(/\s+/g, " ").trim();
  return clean && clean.length <= max ? clean : void 0;
}
function httpsUrl(value) {
  const raw = text(value, LIMITS.url);
  if (!raw) return void 0;
  try {
    const url = new URL(raw);
    return url.protocol === "https:" ? url.href : void 0;
  } catch {
    return void 0;
  }
}
function count(value, fallback, min, max) {
  return Math.round(amount(value, fallback, min, max));
}
function amount(value, fallback, min, max) {
  return typeof value === "number" && Number.isFinite(value) ? Math.min(max, Math.max(min, value)) : fallback;
}
function parseFeed(json) {
  const root = json && typeof json === "object" ? json : {};
  const s = root.schedule && typeof root.schedule === "object" ? root.schedule : {};
  const schedule = {
    firstAfter: count(s.firstAfter, defaultSchedule.firstAfter, 1, 100),
    every: count(s.every, defaultSchedule.every, 2, 100),
    minHours: amount(s.minHours, defaultSchedule.minHours, 0, 24 * 30),
    seconds: count(s.seconds, defaultSchedule.seconds, 0, 15)
  };
  const seen = /* @__PURE__ */ new Set();
  const ads = [];
  for (const entry of Array.isArray(root.ads) ? root.ads : []) {
    if (!entry || typeof entry !== "object") continue;
    const e = entry;
    if (e.active === false) continue;
    const ad = {
      id: text(e.id, LIMITS.id),
      name: text(e.name, LIMITS.name),
      line: text(e.line, LIMITS.line),
      cta: text(e.cta, LIMITS.cta),
      url: httpsUrl(e.url),
      image: httpsUrl(e.image)
    };
    if (!ad.id || !ad.name || !ad.line || !ad.cta || !ad.url || seen.has(ad.id)) continue;
    seen.add(ad.id);
    ads.push(ad.image ? ad : { id: ad.id, name: ad.name, line: ad.line, cta: ad.cta, url: ad.url });
  }
  return { schedule, upgradeUrl: httpsUrl(root.upgradeUrl) ?? "", ads };
}
function adBeforeDownload(state, feed, now) {
  if (state.adFree) return state.due ? { ...state, due: void 0 } : state;
  if (state.due) return state;
  const { schedule, ads } = feed;
  if (ads.length === 0) return state;
  const firstAd = state.shownAt === 0;
  const enough = firstAd ? state.saved >= schedule.firstAfter : state.sinceAd >= schedule.every;
  const rested = firstAd || now - state.shownAt >= schedule.minHours * 36e5;
  if (!enough || !rested) return state;
  const ad = ads[state.next % ads.length];
  return { ...state, due: { ad, remainingMs: schedule.seconds * 1e3 } };
}
function countSave(state) {
  return { ...state, saved: state.saved + 1, sinceAd: state.sinceAd + 1, adThisSave: false };
}

// src/sw/ads.ts
var FEED_TTL_MS = 6 * 36e5;
async function loadFeed(now = Date.now()) {
  const cached = (await chrome.storage.local.get(storageKeys.adFeed))[storageKeys.adFeed];
  if (cached && now - cached.fetchedAt < FEED_TTL_MS) return cached.feed;
  try {
    const res = await fetch(ADS_FEED_URL, { credentials: "omit", cache: "no-cache" });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const feed = parseFeed(await res.json());
    await chrome.storage.local.set({ [storageKeys.adFeed]: { feed, fetchedAt: now } });
    return feed;
  } catch {
    if (cached) return cached.feed;
    const bundled = await fetch(chrome.runtime.getURL("ads.json")).then((r) => r.json()).catch(() => ({}));
    return parseFeed(bundled);
  }
}
async function loadAdState() {
  const stored = (await chrome.storage.local.get(storageKeys.ads))[storageKeys.ads];
  return { ...emptyAdState, ...stored };
}
async function gateDownload() {
  const [state, feed] = await Promise.all([loadAdState(), loadFeed()]);
  const next = adBeforeDownload(state, feed, Date.now());
  if (next !== state) await chrome.storage.local.set({ [storageKeys.ads]: next });
  return Boolean(next.due);
}
async function countSaveForAds() {
  const state = await loadAdState();
  await chrome.storage.local.set({ [storageKeys.ads]: countSave(state) });
  return Boolean(state.adThisSave);
}

// src/sw/asks.ts
async function noteSaved() {
  const hadAd = await countSaveForAds().catch(() => false);
  const state = await updateAsks(hadAd ? quietSave : afterSave);
  if (!state.due || hadAd) return;
  const open = await chrome.runtime.getContexts({
    contextTypes: ["POPUP", "SIDE_PANEL"]
  });
  if (open.length) return;
  if (await chrome.action.getPopup({}) === "") return;
  await chrome.action.openPopup().catch(() => {
  });
}

// src/shared/xml.ts
var ENTITIES = { amp: "&", lt: "<", gt: ">", quot: '"', apos: "'" };
function decode(s) {
  return s.replace(/&(#x[0-9a-f]+|#\d+|[a-z]+);/gi, (whole, ent) => {
    if (ent[0] === "#") {
      const code = ent[1] === "x" || ent[1] === "X" ? parseInt(ent.slice(2), 16) : parseInt(ent.slice(1), 10);
      return Number.isFinite(code) ? String.fromCodePoint(code) : whole;
    }
    return ENTITIES[ent.toLowerCase()] ?? whole;
  });
}
var localName = (qname) => qname.slice(qname.indexOf(":") + 1);
function parseXml(xml) {
  const root = { name: "#document", attrs: {}, children: [], text: "", content: [] };
  const addText = (t) => {
    const top2 = stack[stack.length - 1];
    top2.text += t;
    top2.content.push(t);
  };
  const stack = [root];
  let i = 0;
  while (i < xml.length) {
    const lt = xml.indexOf("<", i);
    const textEnd = lt < 0 ? xml.length : lt;
    if (textEnd > i) addText(decode(xml.slice(i, textEnd)));
    if (lt < 0) break;
    if (xml.startsWith("<!--", lt)) {
      const end = xml.indexOf("-->", lt + 4);
      if (end < 0) throw new Error("Unclosed XML comment");
      i = end + 3;
    } else if (xml.startsWith("<![CDATA[", lt)) {
      const end = xml.indexOf("]]>", lt + 9);
      if (end < 0) throw new Error("Unclosed CDATA section");
      addText(xml.slice(lt + 9, end));
      i = end + 3;
    } else if (xml[lt + 1] === "?" || xml[lt + 1] === "!") {
      const end = xml.indexOf(">", lt);
      if (end < 0) throw new Error("Unclosed XML declaration");
      i = end + 1;
    } else if (xml[lt + 1] === "/") {
      const end = xml.indexOf(">", lt);
      if (end < 0) throw new Error("Unclosed end tag");
      const name = localName(xml.slice(lt + 2, end).trim());
      const open = stack.pop();
      if (!open || open.name !== name || stack.length === 0) throw new Error(`Unexpected </${name}>`);
      i = end + 1;
    } else {
      const tag = /^<([^\s/>]+)/.exec(xml.slice(lt, lt + 256));
      if (!tag) throw new Error("Broken start tag");
      const el = { name: localName(tag[1]), attrs: {}, children: [], text: "", content: [] };
      const attrRe = /\s*([^\s=/>]+)\s*=\s*("([^"]*)"|'([^']*)')|\s*(\/?)>/y;
      attrRe.lastIndex = lt + tag[0].length;
      let closed = false;
      let selfClosing = false;
      for (; ; ) {
        const m = attrRe.exec(xml);
        if (!m) throw new Error(`Broken attributes in <${el.name}>`);
        if (m[1] !== void 0) {
          el.attrs[localName(m[1])] = decode(m[3] ?? m[4] ?? "");
        } else {
          closed = true;
          selfClosing = m[5] === "/";
        }
        if (closed) break;
      }
      i = attrRe.lastIndex;
      stack[stack.length - 1].children.push(el);
      stack[stack.length - 1].content.push(el);
      if (!selfClosing) stack.push(el);
    }
  }
  if (stack.length !== 1) throw new Error(`Unclosed <${stack[stack.length - 1].name}>`);
  const top = root.children[0];
  if (!top) throw new Error("Empty XML document");
  return top;
}
var child = (el, name) => el?.children.find((c) => c.name === name);
var childrenNamed = (el, name) => el?.children.filter((c) => c.name === name) ?? [];

// src/shared/dash.ts
function parseIsoDuration(value) {
  if (!value) return void 0;
  const m = /^P(?:(\d+(?:\.\d+)?)D)?(?:T(?:(\d+(?:\.\d+)?)H)?(?:(\d+(?:\.\d+)?)M)?(?:(\d+(?:\.\d+)?)S)?)?$/.exec(value.trim());
  if (!m) return void 0;
  const [, d = "0", h = "0", min = "0", s = "0"] = m;
  return Number(d) * 86400 + Number(h) * 3600 + Number(min) * 60 + Number(s);
}
function parseRange(value) {
  const m = value && /^(\d+)-(\d+)$/.exec(value.trim());
  return m ? { start: Number(m[1]), end: Number(m[2]) } : void 0;
}
var num2 = (v) => v === void 0 || v === "" || Number.isNaN(Number(v)) ? void 0 : Number(v);
function resolve2(uri, base) {
  try {
    return new URL(uri, base).href;
  } catch {
    return uri;
  }
}
function withBase(base, el) {
  const b = child(el, "BaseURL")?.text.trim();
  return b ? resolve2(b, base) : base;
}
function expandTemplate2(template, vars) {
  return template.replace(/\$(\w*)(?:%0(\d+)d)?\$/g, (whole, name, width) => {
    if (name === "") return "$";
    const value = vars[name];
    if (value === void 0) return whole;
    return width ? String(value).padStart(Number(width), "0") : String(value);
  });
}
function inherited(name, levels) {
  const found = levels.map((l) => child(l, name)).filter((e) => !!e);
  if (!found.length) return void 0;
  const attrs = {};
  let children = [];
  for (const el of found) {
    Object.assign(attrs, el.attrs);
    if (el.children.length) children = el.children;
  }
  return { attrs, children };
}
function templateSegments(t, base, rep, periodDuration, isLive = false) {
  const timescale = num2(t.attrs.timescale) ?? 1;
  const startNumber = num2(t.attrs.startNumber) ?? 1;
  const vars = { RepresentationID: rep.id, Bandwidth: rep.bandwidth };
  const init = t.attrs.initialization ? { url: resolve2(expandTemplate2(t.attrs.initialization, vars), base) } : void 0;
  const media = t.attrs.media;
  if (!media) return { kind: "list", init, segments: [] };
  const segments = [];
  const timeline = t.children.find((c) => c.name === "SegmentTimeline");
  if (timeline) {
    const pto = num2(t.attrs.presentationTimeOffset) ?? 0;
    const end = periodDuration !== void 0 ? pto + periodDuration * timescale : void 0;
    let time = 0;
    let number = startNumber;
    const entries = childrenNamed(timeline, "S");
    entries.forEach((s, i) => {
      const d = num2(s.attrs.d) ?? 0;
      if (s.attrs.t !== void 0) time = num2(s.attrs.t) ?? time;
      let repeat = num2(s.attrs.r) ?? 0;
      if (repeat < 0) {
        const next = num2(entries[i + 1]?.attrs.t) ?? end;
        repeat = next !== void 0 && d > 0 ? Math.ceil((next - time) / d) - 1 : 0;
      }
      for (let k = 0; k <= repeat && d > 0; k++) {
        segments.push({ url: resolve2(expandTemplate2(media, { ...vars, Number: number, Time: time }), base), duration: d / timescale });
        time += d;
        number++;
      }
    });
  } else {
    const duration = num2(t.attrs.duration);
    if (duration && isLive)
      return { kind: "live-template", init, media, base, vars, timescale, duration, startNumber, pto: num2(t.attrs.presentationTimeOffset) ?? 0 };
    if (duration && periodDuration !== void 0) {
      const count2 = Math.ceil(periodDuration * timescale / duration - 1e-6);
      for (let k = 0; k < count2; k++) {
        const left = periodDuration - k * duration / timescale;
        segments.push({
          url: resolve2(expandTemplate2(media, { ...vars, Number: startNumber + k, Time: k * duration }), base),
          duration: Math.min(duration / timescale, left)
        });
      }
    }
  }
  return { kind: "list", init, segments };
}
function listSegments(l, base, periodDuration) {
  const timescale = num2(l.attrs.timescale) ?? 1;
  const duration = num2(l.attrs.duration);
  const initEl = l.children.find((c) => c.name === "Initialization");
  const init = initEl ? { url: initEl.attrs.sourceURL ? resolve2(initEl.attrs.sourceURL, base) : base, range: parseRange(initEl.attrs.range) } : void 0;
  const urls = l.children.filter((c) => c.name === "SegmentURL");
  const segments = urls.map((s, k) => {
    const each = duration ? duration / timescale : periodDuration !== void 0 ? periodDuration / urls.length : void 0;
    const left = periodDuration !== void 0 && duration ? periodDuration - k * duration / timescale : void 0;
    return {
      url: s.attrs.media ? resolve2(s.attrs.media, base) : base,
      range: parseRange(s.attrs.mediaRange),
      duration: each !== void 0 && left !== void 0 ? Math.min(each, left) : each
    };
  });
  return { kind: "list", init, segments };
}
function kindOf(mime, contentType, codecs) {
  const type = contentType ?? mime.split("/")[0];
  if (type === "video" || type === "audio" || type === "text") return type;
  if (mime === "application/ttml+xml" || codecs === "wvtt" || codecs === "stpp") return "text";
  return "other";
}
function periodDurations(periods, total) {
  return periods.map((p, i) => {
    const own = parseIsoDuration(p.attrs.duration);
    if (own !== void 0) return own;
    const start = parseIsoDuration(p.attrs.start) ?? 0;
    const nextStart = parseIsoDuration(periods[i + 1]?.attrs.start);
    if (nextStart !== void 0) return nextStart - start;
    return total !== void 0 ? total - start : void 0;
  });
}
function parseMpd(text2, mpdUrl) {
  const mpd = parseXml(text2);
  if (mpd.name !== "MPD") throw new Error("Not a DASH manifest");
  const isLive = mpd.attrs.type === "dynamic";
  const total = parseIsoDuration(mpd.attrs.mediaPresentationDuration);
  const periods = childrenNamed(mpd, "Period");
  const durations = periodDurations(periods, total);
  let index = 0;
  durations.forEach((d, i) => {
    if ((d ?? 0) > (durations[index] ?? 0)) index = i;
  });
  const period = periods[index];
  const duration = durations[index] ?? total;
  const representations = [];
  const mpdBase = withBase(mpdUrl, mpd);
  const periodBase = withBase(mpdBase, period);
  childrenNamed(period, "AdaptationSet").forEach((set, setIndex) => {
    const trickPlay = [...childrenNamed(set, "EssentialProperty"), ...childrenNamed(set, "SupplementalProperty")].some(
      (p) => /trickmode/i.test(p.attrs.schemeIdUri ?? "")
    );
    if (trickPlay) return;
    const setBase = withBase(periodBase, set);
    const setDrm = childrenNamed(set, "ContentProtection").length > 0;
    const isMain = childrenNamed(set, "Role").some((r) => r.attrs.value === "main");
    childrenNamed(set, "Representation").forEach((rep, repIndex) => {
      const id = rep.attrs.id ?? String(repIndex);
      const mime = (rep.attrs.mimeType ?? set.attrs.mimeType ?? "").toLowerCase();
      const codecs = rep.attrs.codecs ?? set.attrs.codecs;
      const bandwidth = num2(rep.attrs.bandwidth);
      const base = withBase(setBase, rep);
      const levels = [period, set, rep];
      const template = inherited("SegmentTemplate", levels);
      const list2 = inherited("SegmentList", levels);
      const segBase = inherited("SegmentBase", levels);
      let segments;
      if (template) segments = templateSegments(template, base, { id, bandwidth }, duration, isLive);
      else if (list2) segments = listSegments(list2, base, duration);
      else if (segBase?.attrs.indexRange) {
        const initEl = segBase.children.find((c) => c.name === "Initialization");
        segments = { kind: "indexed", url: base, index: parseRange(segBase.attrs.indexRange), init: parseRange(initEl?.attrs.range) };
      } else segments = { kind: "file", url: base };
      representations.push({
        key: `${setIndex}:${id}`,
        kind: kindOf(mime, set.attrs.contentType, codecs),
        mime,
        codecs,
        bandwidth,
        width: num2(rep.attrs.width ?? set.attrs.width),
        height: num2(rep.attrs.height ?? set.attrs.height),
        lang: rep.attrs.lang ?? set.attrs.lang,
        isMain,
        label: (child(rep, "Label") ?? child(set, "Label"))?.text.trim() || void 0,
        hasDrm: setDrm || childrenNamed(rep, "ContentProtection").length > 0,
        segments
      });
    });
  });
  const media = representations.filter((r) => r.kind === "video" || r.kind === "audio");
  const availability = Date.parse(mpd.attrs.availabilityStartTime ?? "");
  return {
    isLive,
    availabilityStart: isLive && Number.isFinite(availability) ? availability : void 0,
    periodStart: isLive ? parseIsoDuration(period?.attrs.start) ?? 0 : void 0,
    updatePeriod: isLive ? parseIsoDuration(mpd.attrs.minimumUpdatePeriod) : void 0,
    timeShiftDepth: isLive ? parseIsoDuration(mpd.attrs.timeShiftBufferDepth) : void 0,
    duration,
    hasDrm: media.length > 0 && media.every((r) => r.hasDrm),
    representations
  };
}
function isMp4Family(rep) {
  if (rep.mime.endsWith("/webm")) return false;
  return !/^(vp8|vp9|vp09|vorbis|opus)/i.test(rep.codecs ?? "");
}
var needsWebm = (rep) => /^vorbis/i.test(rep?.codecs ?? "");
function bestAudio(m) {
  return m.representations.filter((r) => r.kind === "audio" && !r.hasDrm).sort(
    (a, b) => Number(needsWebm(a)) - Number(needsWebm(b)) || Number(isMp4Family(b)) - Number(isMp4Family(a)) || Number(b.isMain) - Number(a.isMain) || (b.bandwidth ?? 0) - (a.bandwidth ?? 0)
  )[0];
}
function listDashVariants(m, mpdUrl) {
  const audio = bestAudio(m);
  const all = m.representations.filter((r) => r.kind === "video" && !r.hasDrm).sort((a, b) => (b.height ?? 0) - (a.height ?? 0) || Number(isMp4Family(b)) - Number(isMp4Family(a)) || (b.bandwidth ?? 0) - (a.bandwidth ?? 0));
  const mp4Heights = new Set(all.filter(isMp4Family).map((v) => v.height));
  const videos = all.filter((v) => isMp4Family(v) || !mp4Heights.has(v.height));
  const out = videos.map((v) => ({
    id: "",
    label: "",
    height: v.height,
    width: v.width,
    bandwidth: v.bandwidth,
    codecs: [v.codecs, audio?.codecs].filter(Boolean).join(",") || void 0,
    url: mpdUrl,
    videoRep: v.key,
    audioRep: audio?.key,
    audioLanguage: audio?.lang,
    audioCodecs: audio?.codecs,
    webm: needsWebm(audio) || void 0
  }));
  if (audio) {
    out.push({
      id: "",
      label: "Audio only",
      audioOnly: true,
      bandwidth: audio.bandwidth,
      url: mpdUrl,
      audioRep: audio.key,
      audioLanguage: audio.lang,
      audioCodecs: audio.codecs,
      webm: needsWebm(audio) || void 0
    });
  }
  return labelVariants(out);
}
function dashChildUrls(m) {
  const urls = /* @__PURE__ */ new Set();
  for (const r of m.representations) {
    if (r.segments.kind === "live-template") {
      if (r.segments.init) urls.add(r.segments.init.url);
    } else if (r.segments.kind !== "list") urls.add(r.segments.url);
    else {
      if (r.segments.init) urls.add(r.segments.init.url);
      for (const s of r.segments.segments) if (s.range) urls.add(s.url);
    }
  }
  return [...urls];
}
function parseSidx(bytes, offset, url) {
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  let size = view.getUint32(0);
  const type = String.fromCharCode(...bytes.subarray(4, 8));
  if (type !== "sidx") throw new Error("No segment index (sidx) where the manifest said");
  let p = 8;
  if (size === 1) {
    size = Number(view.getBigUint64(8));
    p = 16;
  }
  const version = view.getUint8(p);
  p += 4;
  p += 4;
  const timescale = view.getUint32(p);
  p += 4;
  let firstOffset;
  if (version === 0) {
    p += 4;
    firstOffset = view.getUint32(p);
    p += 4;
  } else {
    p += 8;
    firstOffset = Number(view.getBigUint64(p));
    p += 8;
  }
  p += 2;
  const count2 = view.getUint16(p);
  p += 2;
  let start = offset + size + firstOffset;
  const refs = [];
  for (let i = 0; i < count2; i++) {
    const word = view.getUint32(p);
    if (word >>> 31) throw new Error("Nested segment indexes aren't supported yet");
    const length = word & 2147483647;
    const duration = view.getUint32(p + 4) / timescale;
    refs.push({ url, range: { start, end: start + length - 1 }, duration });
    start += length;
    p += 12;
  }
  return refs;
}
function liveSegments(m, rep, now) {
  const seg = rep.segments;
  if (seg.kind === "list") return { init: seg.init, segments: seg.segments };
  if (seg.kind !== "live-template" || m.availabilityStart === void 0) return { segments: [] };
  const each = seg.duration / seg.timescale;
  const elapsed = (now - m.availabilityStart) / 1e3 - (m.periodStart ?? 0);
  const last = Math.floor(elapsed / each) - 1;
  const depth = m.timeShiftDepth ?? Infinity;
  const first = Math.max(0, Number.isFinite(depth) ? Math.floor((elapsed - depth) / each) : 0);
  const segments = [];
  for (let k = first; k <= last; k++) {
    segments.push({
      url: resolve2(expandTemplate2(seg.media, { ...seg.vars, Number: seg.startNumber + k, Time: seg.pto + k * seg.duration }), seg.base),
      duration: each
    });
  }
  return { init: seg.init, segments };
}
async function resolveSegments(rep, duration, fetchRange2) {
  const seg = rep.segments;
  if (seg.kind === "list") return { init: seg.init, segments: seg.segments };
  if (seg.kind === "file") return { segments: [{ url: seg.url, duration }] };
  if (seg.kind === "live-template") return { init: seg.init, segments: [] };
  const index = await fetchRange2(seg.url, seg.index);
  const segments = parseSidx(index, seg.index.start, seg.url);
  const init = { url: seg.url, range: seg.init ?? { start: 0, end: seg.index.start - 1 } };
  return { init, segments };
}
var byteRange = (r) => `${r.end - r.start + 1}@${r.start}`;
function hlsMediaPlaylist(init, segments) {
  const target = Math.max(1, ...segments.map((s) => Math.ceil(s.duration ?? 1)));
  const lines = ["#EXTM3U", "#EXT-X-VERSION:7", `#EXT-X-TARGETDURATION:${target}`, "#EXT-X-PLAYLIST-TYPE:VOD", "#EXT-X-INDEPENDENT-SEGMENTS"];
  if (init) lines.push(`#EXT-X-MAP:URI="${init.url}"${init.range ? `,BYTERANGE="${byteRange(init.range)}"` : ""}`);
  for (const s of segments) {
    lines.push(`#EXTINF:${(s.duration ?? 1).toFixed(6)},`);
    if (s.range) lines.push(`#EXT-X-BYTERANGE:${byteRange(s.range)}`);
    lines.push(s.url);
  }
  lines.push("#EXT-X-ENDLIST", "");
  return lines.join("\n");
}
function listDashSubtitles(m) {
  const out = [];
  for (const r of m.representations) {
    if (r.kind !== "text" || !/^(text\/vtt|application\/ttml\+xml)$/.test(r.mime)) continue;
    const seg = r.segments;
    const source = seg.kind === "file" ? { kind: "file", url: seg.url } : seg.kind === "list" && seg.segments.length && seg.segments.every((s) => !s.range) ? { kind: "segments", urls: seg.segments.map((s) => s.url) } : void 0;
    if (source) out.push({ id: `dash-${r.key}`, label: r.label ?? r.lang ?? `Subtitles ${out.length + 1}`, lang: r.lang, source });
  }
  return out;
}

// src/sw/replay.ts
var REPLAYED = /* @__PURE__ */ new Set(["cookie", "referer", "origin", "authorization"]);
var MAX_RULES_PER_JOB = 500;
function headersToReplay(sent) {
  const out = {};
  for (const [name, value] of Object.entries(sent)) {
    if (REPLAYED.has(name) || name.startsWith("x-")) out[name] = value;
  }
  return out;
}
function urlDirectory(url) {
  const u = new URL(url);
  const dir = u.pathname.slice(0, u.pathname.lastIndexOf("/") + 1);
  return `${u.origin}${dir}`;
}
function replayScopes(urls, maxDirs = 50) {
  const dirs = [...new Set(urls.map(urlDirectory))];
  if (dirs.length <= maxDirs) return dirs;
  return [...new Set(urls.map((u) => `${new URL(u).origin}/`))];
}
function escapeUrlFilter(s) {
  return s.replace(/\*/g, "%2A").replace(/\^/g, "%5E").replace(/\|/g, "%7C");
}
function buildReplayRules(urls, sent, firstId) {
  const headers = headersToReplay(sent);
  const names = Object.keys(headers);
  if (names.length === 0) return [];
  const dirs = [...new Set(urls.map(urlDirectory))].slice(0, MAX_RULES_PER_JOB);
  return dirs.map((dir, i) => ({
    id: firstId + i,
    priority: 1,
    action: {
      type: "modifyHeaders",
      requestHeaders: names.map((header2) => ({
        header: header2,
        operation: "set",
        value: headers[header2]
      }))
    },
    condition: {
      urlFilter: `|${escapeUrlFilter(dir)}`,
      // -1 is chrome.tabs.TAB_ID_NONE: requests made by the extension itself.
      tabIds: [-1],
      resourceTypes: ["xmlhttprequest", "media", "other"]
    }
  }));
}
async function clearStaleRules() {
  const rules = await chrome.declarativeNetRequest.getSessionRules();
  await chrome.declarativeNetRequest.updateSessionRules({ removeRuleIds: rules.map((r) => r.id) });
}
var queue = Promise.resolve();
function installReplay(urls, sent) {
  const run = queue.then(async () => {
    const existing = await chrome.declarativeNetRequest.getSessionRules();
    const firstId = existing.reduce((max, r) => Math.max(max, r.id), 0) + 1;
    const rules = buildReplayRules(urls, sent, firstId);
    if (rules.length) await chrome.declarativeNetRequest.updateSessionRules({ addRules: rules });
    return rules.map((r) => r.id);
  });
  queue = run.catch(() => {
  });
  return run;
}
async function removeReplay(ids) {
  if (ids.length) await chrome.declarativeNetRequest.updateSessionRules({ removeRuleIds: ids });
}

// src/sw/hls-probe.ts
var PLAYLIST_TIMEOUT_MS = 15e3;
var MAX_PLAYLIST_BYTES = 8 * 1024 * 1024;
async function fetchPlaylistText(url) {
  const res = await fetch(url, { cache: "no-store", signal: AbortSignal.timeout(PLAYLIST_TIMEOUT_MS) });
  if (!res.ok) throw new Error(`The server answered ${res.status} for the playlist`);
  const text2 = await res.text();
  if (text2.length > MAX_PLAYLIST_BYTES) throw new Error("The playlist is too large");
  return text2;
}
async function fetchWithReplay(url, sent) {
  const rules = await installReplay([url], sent);
  try {
    return await fetchPlaylistText(url);
  } finally {
    await removeReplay(rules);
  }
}
var RETRY_DELAYS_MS = [1e3, 3e3];
async function fetchInFrame(url, frame) {
  const [res] = await chrome.scripting.executeScript({
    target: { tabId: frame.tabId, frameIds: [frame.frameId] },
    func: async (u) => {
      const r = await fetch(u, { cache: "no-store", credentials: "include" });
      return { status: r.status, text: r.ok ? await r.text() : "" };
    },
    args: [url]
  });
  const out = res?.result;
  if (!out || out.status < 200 || out.status >= 300) throw new Error(`The server answered ${out?.status ?? "nothing"} for the playlist`);
  if (out.text.length > MAX_PLAYLIST_BYTES) throw new Error("The playlist is too large");
  return out.text;
}
async function fetchForProbe(url, sent, frame) {
  const tries = [() => fetchWithReplay(url, sent), ...frame ? [() => fetchInFrame(url, frame)] : []];
  let last;
  for (const delay of [0, ...RETRY_DELAYS_MS]) {
    if (delay) await new Promise((r) => setTimeout(r, delay));
    for (const attempt of tries) {
      try {
        return await attempt();
      } catch (err) {
        last = err;
      }
    }
  }
  throw last;
}
function mediaFacts(pl) {
  return {
    durationSec: pl.duration > 0 ? Math.round(pl.duration * 10) / 10 : void 0,
    isLive: !pl.endList && pl.playlistType !== "VOD",
    hasDrm: pl.keys.some(isDrmKey)
  };
}
async function probeHls(url, sent, frame) {
  let text2;
  try {
    text2 = await fetchForProbe(url, sent, frame);
  } catch {
    return {};
  }
  if (!text2.trimStart().startsWith("#EXTM3U")) return null;
  try {
    const pl = parseM3u8(text2, url);
    if (pl.kind === "media") {
      const variant = { id: "0", label: "Original", url };
      return { variants: [variant], ...mediaFacts(pl) };
    }
    const variants = listVariants(pl);
    const childUrls = [
      .../* @__PURE__ */ new Set([...pl.variants.map((v) => v.uri), ...pl.renditions.flatMap((r) => r.uri ? [r.uri] : [])])
    ];
    const sessionDrm = pl.sessionKeys.some(isDrmKey);
    const subtitles = listHlsSubtitles(pl);
    const best = variants[0];
    if (!best) return { variants, childUrls, subtitles, hasDrm: sessionDrm };
    const media = parseM3u8(await fetchForProbe(best.url, sent, frame), best.url);
    const facts = media.kind === "media" ? mediaFacts(media) : { hasDrm: false };
    return { variants, childUrls, subtitles, ...facts, hasDrm: sessionDrm || facts.hasDrm };
  } catch {
    return {};
  }
}
async function variantUrls(variant, sent) {
  const playlists = [variant.url, variant.audioUrl].filter((u) => !!u);
  const lists = await Promise.all(
    playlists.map(async (u) => {
      const pl = parseM3u8(await fetchWithReplay(u, sent), u);
      return pl.kind === "media" ? [u, ...pl.segments, ...pl.otherUris] : [u];
    })
  );
  return lists.flat();
}

// src/sw/dash-probe.ts
var INDEX_TIMEOUT_MS = 15e3;
async function readManifest(url, sent) {
  return parseMpd(await fetchWithReplay(url, sent), url);
}
async function probeDash(url, sent, frame) {
  let text2;
  try {
    text2 = await fetchForProbe(url, sent, frame);
  } catch {
    return {};
  }
  if (!/<(\w+:)?MPD[\s>]/.test(text2)) return null;
  try {
    const m = parseMpd(text2, url);
    return {
      variants: listDashVariants(m, url),
      childUrls: dashChildUrls(m),
      durationSec: m.duration !== void 0 ? Math.round(m.duration * 10) / 10 : void 0,
      isLive: m.isLive,
      hasDrm: m.hasDrm,
      subtitles: listDashSubtitles(m)
    };
  } catch {
    return {};
  }
}
async function fetchRange(url, range, sent) {
  const rules = await installReplay([url], sent);
  try {
    const res = await fetch(url, {
      headers: { Range: `bytes=${range.start}-${range.end}` },
      signal: AbortSignal.timeout(INDEX_TIMEOUT_MS)
    });
    if (!res.ok) throw new Error(`The server answered ${res.status} for the segment index`);
    const bytes = new Uint8Array(await res.arrayBuffer());
    return res.status === 206 ? bytes : bytes.subarray(range.start, range.end + 1);
  } finally {
    await removeReplay(rules);
  }
}
async function dropMissingTail(segments, sent) {
  const last = segments.at(-1);
  const before = segments.at(-2);
  if (!last || !before || last.range || (last.duration ?? 0) >= (before.duration ?? 0) / 2) return segments;
  const rules = await installReplay([last.url], sent);
  try {
    const res = await fetch(last.url, { headers: { Range: "bytes=0-0" }, signal: AbortSignal.timeout(INDEX_TIMEOUT_MS) });
    void res.body?.cancel();
    return res.status === 404 || res.status === 410 ? segments.slice(0, -1) : segments;
  } catch {
    return segments;
  } finally {
    await removeReplay(rules);
  }
}
async function planDash(manifestUrl, variant, sent) {
  const m = await readManifest(manifestUrl, sent);
  const urls = [manifestUrl];
  const rep = (key) => {
    if (!key) return void 0;
    const found = m.representations.find((r) => r.key === key);
    if (!found) throw new Error("This quality is no longer in the stream's manifest. Reload the page and try again.");
    if (found.hasDrm) throw new Error("This video is protected by DRM and can't be downloaded.");
    return found;
  };
  const audioRep = rep(variant.audioRep);
  const videoRep = variant.audioOnly ? void 0 : rep(variant.videoRep);
  if (variant.audioOnly && !audioRep) throw new Error("This stream has no separate audio track.");
  if (!variant.audioOnly && !videoRep) throw new Error("This quality is no longer in the stream's manifest. Reload the page and try again.");
  const reps = [videoRep, audioRep].filter((r) => r !== void 0);
  if (m.isLive) {
    for (const r of reps) {
      const { init, segments } = liveSegments(m, r, Date.now());
      urls.push(...init ? [init.url] : [], ...segments.slice(-1).map((s) => s.url));
    }
    return { kind: "live", reps: reps.map((r) => r.key), urls };
  }
  if (reps.some((r) => !isMp4Family(r))) {
    const tracks = [];
    for (const r of reps) {
      if (r.segments.kind === "file" || r.segments.kind === "indexed") {
        urls.push(r.segments.url);
        tracks.push([{ url: r.segments.url }]);
        continue;
      }
      if (r.segments.kind !== "list") throw new Error("This stream's manifest lists no segments.");
      const segments = await dropMissingTail(r.segments.segments, sent);
      if (!segments.length) throw new Error("This stream's manifest lists no segments.");
      const parts = [...r.segments.init ? [r.segments.init] : [], ...segments].map((s) => ({ url: s.url, range: s.range }));
      urls.push(...parts.map((p) => p.url));
      tracks.push(parts);
    }
    return { kind: "tracks", tracks, urls };
  }
  const playlist = async (r) => {
    if (!r) return void 0;
    const resolved = await resolveSegments(r, m.duration, (u, range) => fetchRange(u, range, sent));
    const init = resolved.init;
    const segments = await dropMissingTail(resolved.segments, sent);
    if (!segments.length) throw new Error("This stream's manifest lists no segments.");
    if (init) urls.push(init.url);
    urls.push(...segments.map((s) => s.url));
    return dataUrl(hlsMediaPlaylist(init, segments));
  };
  const audio = await playlist(audioRep);
  if (variant.audioOnly) return { kind: "hls", url: audio, urls };
  const video = await playlist(videoRep);
  return { kind: "hls", url: dataUrl(singleVariantMaster({ ...variant, url: video, audioUrl: audio })), urls };
}

// src/shared/subtitles.ts
function clock(value) {
  const m = /^(?:(\d+):)?(\d{1,2}):(\d{1,2})(?:[.,](\d+))?$/.exec(value.trim());
  if (!m) return void 0;
  const [, h = "0", min, s, frac = "0"] = m;
  return Number(h) * 3600 + Number(min) * 60 + Number(s) + Number(`0.${frac}`);
}
var stripTags = (s) => s.replace(/<[^>]+>/g, "").replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&nbsp;/g, " ");
function parseVtt(text2) {
  const cues = [];
  const blocks = text2.replace(/\r\n?/g, "\n").split(/\n{2,}/);
  for (const block of blocks) {
    const lines = block.split("\n");
    const at = lines.findIndex((l) => l.includes("-->"));
    if (at < 0) continue;
    const [from, rest = ""] = lines[at].split("-->");
    const start = clock(from ?? "");
    const end = clock(rest.trim().split(/\s+/)[0] ?? "");
    const body = lines.slice(at + 1).map(stripTags).join("\n").trim();
    if (start === void 0 || end === void 0 || !body) continue;
    cues.push({ start, end, text: body });
  }
  return cues;
}
function ttmlTime(value, tickRate, frameRate) {
  if (!value) return void 0;
  const offset = /^([\d.]+)(h|m|s|ms|f|t)$/.exec(value.trim());
  if (offset) {
    const n = Number(offset[1]);
    const unit = offset[2];
    return unit === "h" ? n * 3600 : unit === "m" ? n * 60 : unit === "s" ? n : unit === "ms" ? n / 1e3 : unit === "f" ? n / frameRate : n / tickRate;
  }
  const frames = /^(\d+):(\d{2}):(\d{2}):(\d+)$/.exec(value.trim());
  if (frames) return Number(frames[1]) * 3600 + Number(frames[2]) * 60 + Number(frames[3]) + Number(frames[4]) / frameRate;
  return clock(value);
}
function ttmlText(el) {
  return el.content.map((c) => typeof c === "string" ? c.replace(/\s+/g, " ") : c.name === "br" ? "\n" : ttmlText(c)).join("");
}
function parseTtml(text2) {
  const root = parseXml(text2);
  const tickRate = Number(root.attrs.tickRate) || 1e7;
  const frameRate = Number(root.attrs.frameRate) || 30;
  const cues = [];
  const walk = (el) => {
    if (el.name === "p") {
      const start = ttmlTime(el.attrs.begin, tickRate, frameRate);
      const end = ttmlTime(el.attrs.end, tickRate, frameRate) ?? (start !== void 0 ? start + (ttmlTime(el.attrs.dur, tickRate, frameRate) ?? 0) : void 0);
      const body = ttmlText(el).split("\n").map((l) => l.trim()).filter(Boolean).join("\n");
      if (start !== void 0 && end !== void 0 && body) cues.push({ start, end, text: body });
      return;
    }
    el.children.forEach(walk);
  };
  walk(root);
  return cues;
}
function mergeCues(lists) {
  const seen = /* @__PURE__ */ new Set();
  const out = [];
  for (const cue of lists.flat().sort((a, b) => a.start - b.start || a.end - b.end)) {
    const key = `${cue.start.toFixed(3)}|${cue.end.toFixed(3)}|${cue.text}`;
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(cue);
  }
  return out;
}
function srtTime(seconds2) {
  const ms = Math.max(0, Math.round(seconds2 * 1e3));
  const h = Math.floor(ms / 36e5);
  const m = Math.floor(ms % 36e5 / 6e4);
  const s = Math.floor(ms % 6e4 / 1e3);
  const pad = (n, w = 2) => String(n).padStart(w, "0");
  return `${pad(h)}:${pad(m)}:${pad(s)},${pad(ms % 1e3, 3)}`;
}
function toSrt(cues) {
  return cues.map((c, i) => `${i + 1}
${srtTime(c.start)} --> ${srtTime(c.end)}
${c.text}
`).join("\n");
}
function parseSubtitles(text2) {
  const head = text2.trimStart().slice(0, 64);
  if (head.startsWith("WEBVTT")) return parseVtt(text2);
  if (head.startsWith("<")) return parseTtml(text2);
  return parseVtt(text2);
}

// src/sw/subtitles.ts
var SEGMENT_TIMEOUT_MS = 15e3;
var MAX_SEGMENTS = 2e3;
async function fetchText(url) {
  const res = await fetch(url, { signal: AbortSignal.timeout(SEGMENT_TIMEOUT_MS) });
  if (!res.ok) throw new Error(`The server answered ${res.status} for the subtitles`);
  return res.text();
}
async function textUrls(track2) {
  const { source } = track2;
  if (source.kind === "file") return [source.url];
  if (source.kind === "segments") return source.urls;
  const pl = parseM3u8(await fetchPlaylistText(source.url), source.url);
  if (pl.kind !== "media") throw new Error("The subtitle playlist has no segments");
  return pl.segments;
}
function subtitleFilename(videoFilename, track2) {
  const base = videoFilename.replace(/\.[a-z0-9]{1,5}$/i, "");
  const tag = (track2.lang || track2.label || "subtitles").replace(/[^\p{L}\p{N}-]+/gu, "_").slice(0, 24);
  return `${base}.${tag}.srt`;
}
async function saveSubtitles(track2, sent, videoFilename) {
  const playlistUrl = track2.source.kind === "hls" ? [track2.source.url] : [];
  let rules = await installReplay(replayScopes([...playlistUrl, ...track2.source.kind === "file" ? [track2.source.url] : []]), sent);
  try {
    const urls = (await textUrls(track2)).slice(0, MAX_SEGMENTS);
    await removeReplay(rules);
    rules = await installReplay(replayScopes(urls), sent);
    const texts = [];
    for (const url of urls) texts.push(await fetchText(url));
    const cues = mergeCues(texts.map(parseSubtitles));
    if (!cues.length) throw new Error("The subtitles were empty");
    const filename = subtitleFilename(videoFilename, track2);
    await chrome.downloads.download({
      url: `data:application/x-subrip;charset=utf-8,${encodeURIComponent(toSrt(cues))}`,
      filename,
      conflictAction: "uniquify"
    });
    return filename;
  } finally {
    await removeReplay(rules);
  }
}

// src/sw/downloads.ts
var OFFSCREEN_URL = "offscreen.html";
var KEEP_FINISHED_JOBS = 50;
var ARM_TIMEOUT_MS = 3e4;
function sameOrigin(a, b) {
  try {
    return new URL(a).origin === new URL(b).origin;
  } catch {
    return false;
  }
}
var creatingOffscreen;
async function ensureOffscreen() {
  const existing = await chrome.runtime.getContexts({
    contextTypes: ["OFFSCREEN_DOCUMENT"]
  });
  if (existing.length) return;
  creatingOffscreen ??= chrome.offscreen.createDocument({
    url: OFFSCREEN_URL,
    reasons: ["WORKERS"],
    justification: "Runs downloads and remuxing in a Web Worker."
  }).finally(() => creatingOffscreen = void 0);
  await creatingOffscreen;
}
async function toWorker(message) {
  await ensureOffscreen();
  const envelope = { target: "offscreen", message };
  for (let attempt = 0; ; attempt++) {
    try {
      await chrome.runtime.sendMessage(envelope);
      return;
    } catch (err) {
      if (attempt >= 20) throw err;
      await new Promise((r) => setTimeout(r, 100));
    }
  }
}
var Downloads = class {
  jobs = /* @__PURE__ */ new Map();
  loaded;
  writeTimer;
  constructor() {
    this.loaded = chrome.storage.session.get(storageKeys.jobs).then((data) => {
      const stored = data[storageKeys.jobs] ?? {};
      for (const job of Object.values(stored)) if (!this.jobs.has(job.jobId)) this.jobs.set(job.jobId, job);
    });
    chrome.downloads.onChanged.addListener((delta) => void this.onSaveChanged(delta));
    chrome.downloads.onDeterminingFilename.addListener((item, suggest) => {
      const job = [...this.jobs.values()].find((j) => j.chromeDownloadId === item.id);
      if (job) suggest({ filename: job.filename, conflictAction: "uniquify" });
      else suggest();
    });
  }
  async start(tab, item, filenameOverride, variantId, subtitleId) {
    await this.loaded;
    if (item.hasDrm) throw new Error("This video is protected by DRM and can't be downloaded.");
    if (item.type === "mse") return this.recordPlayer(tab, item, filenameOverride);
    let variant;
    const file = item.type === "http" ? item.variants?.find((v) => v.id === variantId) ?? item.variants?.[0] : void 0;
    const fileUrl = file?.url ?? item.url;
    const fileBytes = file ? file.sizeBytes : item.sizeBytes;
    if (item.type !== "http") {
      variant = item.variants?.find((v) => v.id === variantId) ?? item.variants?.[0];
      if (!variant) throw new Error("Couldn't read this stream's playlist. Reload the page and try again.");
    }
    const ext = savedExt(item, variant);
    const settings = await loadSettings();
    const name = filenameOverride ? `${sanitizeFilename(filenameOverride.replace(/\.[a-z0-9]{1,5}$/i, ""), settings.maxLength)}.${ext}` : buildFilename({
      template: settings.template,
      maxLength: settings.maxLength,
      title: item.title ?? tab.title,
      pageUrl: tab.pageUrl,
      mediaUrl: item.url,
      serverFilename: item.serverFilename,
      ext
    });
    const folder = settings.subfolder.split(/[\\/]+/).filter(Boolean).map((part) => sanitizeFilename(part, 64)).join("/");
    const job = {
      jobId: crypto.randomUUID(),
      mediaId: item.id,
      tabId: tab.tabId,
      filename: folder ? `${folder}/${name}` : name,
      state: "running",
      phase: "fetching",
      bytesReceived: 0,
      totalBytes: variant ? void 0 : fileBytes,
      progress: variant && !item.isLive ? 0 : void 0,
      recording: item.isLive || void 0,
      recordedSec: item.isLive ? 0 : void 0,
      variantLabel: (variant ?? file) && item.variants.length > 1 ? (variant ?? file).label : void 0,
      saveAs: settings.saveAs,
      ruleIds: variant ? [] : await installReplay([fileUrl], item.sentHeaders),
      startedAt: Date.now(),
      pageUrl: tab.pageUrl,
      title: item.title ?? tab.title,
      thumbnail: item.thumbnail ?? tab.thumbnail
    };
    this.jobs.set(job.jobId, job);
    this.persist();
    const mime = mimeForFilename(name);
    try {
      if (variant) {
        if (item.type === "dash") {
          const plan = await planDash(item.url, variant, item.sentHeaders);
          job.ruleIds = await installReplay(replayScopes([item.url, ...plan.urls]), item.sentHeaders);
          if (plan.kind === "live") await toWorker({ type: "record-live-dash", jobId: job.jobId, mime, manifestUrl: item.url, reps: plan.reps });
          else if (plan.kind === "tracks") await toWorker({ type: "fetch-tracks", jobId: job.jobId, mime, tracks: plan.tracks });
          else await toWorker({ type: "fetch-hls", jobId: job.jobId, mime, url: plan.url, audioOnly: variant.audioOnly });
        } else {
          const urls = await variantUrls(variant, item.sentHeaders);
          const url = variant.url === item.url || variant.audioOnly ? variant.url : dataUrl(singleVariantMaster(variant));
          job.ruleIds = await installReplay(replayScopes([item.url, ...urls]), item.sentHeaders);
          await toWorker({ type: item.isLive ? "record-live" : "fetch-hls", jobId: job.jobId, mime, url, audioOnly: variant.audioOnly });
        }
      } else {
        await toWorker({
          type: "fetch-file",
          jobId: job.jobId,
          mime,
          url: fileUrl,
          expectedBytes: fileBytes,
          supportsRanges: item.supportsRanges
        });
      }
    } catch (err) {
      await this.fail(job, err instanceof Error ? err.message : String(err));
      throw err;
    }
    const track2 = subtitleId ? [...item.subtitles ?? [], ...tab.subtitles ?? []].find((t) => t.id === subtitleId) : void 0;
    if (track2) {
      saveSubtitles(track2, item.sentHeaders, job.filename).then(
        (file2) => job.subtitleFile = file2,
        (err) => job.subtitleError = err instanceof Error ? err.message : String(err)
      ).finally(() => this.persist());
    }
    return job.jobId;
  }
  /** Player recording: the page's own buffers, collected by the capture frame. */
  async recordPlayer(tab, item, filenameOverride) {
    const settings = await loadSettings();
    const name = filenameOverride ? `${sanitizeFilename(filenameOverride.replace(/\.[a-z0-9]{1,5}$/i, ""), settings.maxLength)}.mp4` : buildFilename({ template: settings.template, maxLength: settings.maxLength, title: item.title ?? tab.title, pageUrl: tab.pageUrl, mediaUrl: item.url, ext: "mp4" });
    const folder = settings.subfolder.split(/[\\/]+/).filter(Boolean).map((part) => sanitizeFilename(part, 64)).join("/");
    const job = {
      jobId: crypto.randomUUID(),
      mediaId: item.id,
      tabId: tab.tabId,
      filename: folder ? `${folder}/${name}` : name,
      state: "running",
      phase: "fetching",
      bytesReceived: 0,
      recording: true,
      saveAs: settings.saveAs,
      startedAt: Date.now(),
      pageUrl: tab.pageUrl,
      title: item.title ?? tab.title,
      thumbnail: item.thumbnail ?? tab.thumbnail,
      player: { frameId: -1, armed: true }
    };
    this.jobs.set(job.jobId, job);
    this.persist();
    try {
      await chrome.tabs.reload(tab.tabId);
    } catch {
      await this.fail(job, "The page isn't reachable any more. Reload it and try again.");
      return job.jobId;
    }
    setTimeout(() => {
      if (job.state === "running" && job.player?.armed)
        void this.fail(job, "The player didn't start after the page reloaded. Play the video, then press Record again.");
    }, ARM_TIMEOUT_MS);
    return job.jobId;
  }
  /** Media on this tab with a download running, which stays listed whatever the page plays next. */
  async busyMedia(tabId) {
    await this.loaded;
    return new Set([...this.jobs.values()].filter((j) => j.tabId === tabId && j.state === "running").map((j) => j.mediaId));
  }
  /** A player in a just-reloaded tab: the armed recording, now bound to its frame. */
  async claimArmed(tabId, frameId, mediaId, pageUrl) {
    await this.loaded;
    const job = [...this.jobs.values()].find((j) => j.tabId === tabId && j.state === "running" && j.player?.armed);
    if (!job || !sameOrigin(job.pageUrl ?? "", pageUrl)) return void 0;
    job.player = { frameId };
    job.mediaId = mediaId;
    this.persist();
    return job;
  }
  /** The capture frame asks for its job; each recording is handed out once. */
  async claimCapture(jobId) {
    await this.loaded;
    const job = this.jobs.get(jobId);
    if (!job?.player || job.player.claimed || job.state !== "running") return void 0;
    job.player.claimed = true;
    return job;
  }
  async cancel(jobId) {
    await this.loaded;
    const job = this.jobs.get(jobId);
    if (!job || job.state !== "running") return;
    if (job.chromeDownloadId !== void 0) await chrome.downloads.cancel(job.chromeDownloadId).catch(() => {
    });
    else if (job.player) {
      if (!job.player.armed) await chrome.tabs.sendMessage(job.tabId, { kind: "mse-cancel", jobId }, { frameId: job.player.frameId }).catch(() => {
      });
      await this.fail(job, "Cancelled");
    } else await toWorker({ type: "cancel", jobId });
  }
  /** Ends a live recording; the worker then saves what it has. */
  async stop(jobId) {
    await this.loaded;
    const job = this.jobs.get(jobId);
    if (job?.state !== "running" || !job.recording || job.phase !== "fetching") return;
    if (job.player?.armed) await this.fail(job, "Cancelled");
    else if (job.player) await chrome.tabs.sendMessage(job.tabId, { kind: "mse-stop", jobId }, { frameId: job.player.frameId }).catch(() => {
    });
    else await toWorker({ type: "stop", jobId });
  }
  /** Messages relayed from the download worker. */
  async onWorkerMessage(msg) {
    await this.loaded;
    const job = this.jobs.get(msg.jobId);
    if (!job || job.state !== "running") return;
    switch (msg.type) {
      case "progress":
        job.bytesReceived = msg.bytes;
        if (msg.totalBytes) job.totalBytes = msg.totalBytes;
        if (msg.fraction !== void 0) job.progress = msg.fraction;
        if (msg.seconds !== void 0) job.recordedSec = msg.seconds;
        this.persist();
        break;
      case "error":
        await this.fail(job, msg.message);
        break;
      case "saved":
        job.chromeDownloadId = msg.downloadId;
        job.filename = msg.filename;
        job.bytesReceived = job.totalBytes = msg.bytes;
        job.phase = "saving";
        this.persist();
        break;
      case "done":
        job.bytesReceived = msg.bytes;
        job.totalBytes = msg.bytes;
        job.phase = "saving";
        await removeReplay(job.ruleIds ?? []);
        job.ruleIds = [];
        try {
          const save = () => chrome.downloads.download({ url: msg.blobUrl, filename: job.filename, conflictAction: "uniquify", saveAs: job.saveAs });
          try {
            job.chromeDownloadId = await save();
          } catch (err) {
            const plain = asciiFilename(job.filename);
            if (!/invalid filename/i.test(String(err)) || plain === job.filename) throw err;
            job.filename = plain;
            job.chromeDownloadId = await save();
          }
          this.persist();
        } catch (err) {
          await this.fail(job, err instanceof Error ? err.message : String(err));
        }
        break;
    }
  }
  async onSaveChanged(delta) {
    await this.loaded;
    const job = [...this.jobs.values()].find((j) => j.chromeDownloadId === delta.id);
    if (!job || job.state !== "running") return;
    const state = delta.state?.current;
    if (state === "complete") {
      const [item] = await chrome.downloads.search({ id: delta.id });
      job.state = "complete";
      job.savedPath = item?.filename;
      this.persist();
      const thumbnail = await this.latestThumbnail(job);
      void addHistory({
        id: job.jobId,
        filename: job.filename,
        savedPath: job.savedPath,
        chromeDownloadId: job.chromeDownloadId,
        pageUrl: job.pageUrl ?? "",
        title: job.title,
        thumbnail,
        bytes: item?.fileSize || item?.totalBytes || job.bytesReceived || void 0,
        // "720p · 2.5 MB": the size is listed on its own.
        quality: job.variantLabel?.split(" \xB7 ")[0],
        recorded: job.recording,
        savedAt: Date.now()
      }).catch(() => {
      });
      void noteSaved().catch(() => {
      });
      void noteActivated().catch(() => {
      });
      void toWorker({ type: "cleanup", jobId: job.jobId });
    } else if (state === "interrupted") {
      await this.fail(job, delta.error?.current === "USER_CANCELED" ? "Cancelled" : delta.error?.current ?? "Saving failed");
    }
  }
  /**
   * Single-page apps often show a placeholder image (the site's logo) when a
   * download starts and the video's own one later; take the newest while the
   * tab still shows that page.
   */
  async latestThumbnail(job) {
    try {
      const key = storageKeys.tab(job.tabId);
      const tab = (await chrome.storage.session.get(key))[key];
      if (!tab || tab.pageUrl !== job.pageUrl) return job.thumbnail;
      return tab.media.find((m) => m.id === job.mediaId)?.thumbnail ?? tab.thumbnail ?? job.thumbnail;
    } catch {
      return job.thumbnail;
    }
  }
  async fail(job, error) {
    job.state = "failed";
    job.error = error;
    await removeReplay(job.ruleIds ?? []);
    job.ruleIds = [];
    this.persist();
    void toWorker({ type: "cleanup", jobId: job.jobId }).catch(() => {
    });
  }
  /** Debounced write of every job (recent finished ones stay listed for the UI). */
  persist() {
    if (this.writeTimer) return;
    this.writeTimer = setTimeout(() => {
      this.writeTimer = void 0;
      const finished = [...this.jobs.values()].filter((j) => j.state !== "running").sort((a, b) => b.startedAt - a.startedAt);
      for (const old of finished.slice(KEEP_FINISHED_JOBS)) this.jobs.delete(old.jobId);
      void chrome.storage.session.set({ [storageKeys.jobs]: Object.fromEntries(this.jobs) });
    }, 200);
  }
};

// src/sw/headers.ts
var TTL_MS = 10 * 60 * 1e3;
var MAX_ENTRIES = 5e3;
var NOT_REPLAYED = /* @__PURE__ */ new Set([
  "range",
  "host",
  "connection",
  "content-length",
  "user-agent",
  "accept-encoding",
  "if-range",
  "if-none-match",
  "if-modified-since",
  "upgrade-insecure-requests",
  "proxy-authorization",
  "proxy-connection",
  "keep-alive",
  "te",
  "trailer",
  "transfer-encoding"
]);
function replayableHeaders(headers) {
  const out = {};
  for (const h of headers ?? []) {
    const name = h.name.toLowerCase();
    if (h.value === void 0 || NOT_REPLAYED.has(name) || name.startsWith("sec-ch-") || name.startsWith("proxy-")) {
      continue;
    }
    out[name] = h.value;
  }
  return out;
}
var HeaderCache = class {
  constructor(now = Date.now) {
    this.now = now;
  }
  now;
  entries = /* @__PURE__ */ new Map();
  put(requestId, headers) {
    if (this.entries.size >= MAX_ENTRIES) this.prune();
    this.entries.set(requestId, { headers, at: this.now() });
  }
  get(requestId) {
    const e = this.entries.get(requestId);
    if (!e) return void 0;
    if (this.now() - e.at > TTL_MS) {
      this.entries.delete(requestId);
      return void 0;
    }
    return e.headers;
  }
  prune() {
    const cutoff = this.now() - TTL_MS;
    for (const [id, e] of this.entries) if (e.at < cutoff) this.entries.delete(id);
    if (this.entries.size >= MAX_ENTRIES) {
      let drop = Math.floor(this.entries.size / 2);
      for (const id of this.entries.keys()) {
        if (drop-- <= 0) break;
        this.entries.delete(id);
      }
    }
  }
};

// src/shared/page-media.ts
var MAX_CANDIDATES = 10;
var NOT_MEDIA_TYPES = /^(text\/html|application\/x-shockwave-flash)/i;
function absolute(url, base) {
  if (typeof url !== "string" || !url.trim()) return void 0;
  try {
    const u = new URL(url.trim(), base);
    return u.protocol === "http:" || u.protocol === "https:" ? u.href : void 0;
  } catch {
    return void 0;
  }
}
function seconds(value) {
  if (typeof value === "number" && value > 0) return value;
  if (typeof value !== "string") return void 0;
  const m = /^P(?:(\d+(?:\.\d+)?)D)?(?:T(?:(\d+(?:\.\d+)?)H)?(?:(\d+(?:\.\d+)?)M)?(?:(\d+(?:\.\d+)?)S)?)?$/i.exec(value.trim());
  if (m && m[0] !== "P" && m[0].toUpperCase() !== "PT") {
    const [, d = "0", h = "0", min = "0", s = "0"] = m;
    return Number(d) * 86400 + Number(h) * 3600 + Number(min) * 60 + Number(s) || void 0;
  }
  const n = Number(value);
  return Number.isFinite(n) && n > 0 ? n : void 0;
}
function imageUrl(value, base) {
  const first = Array.isArray(value) ? value[0] : value;
  if (first && typeof first === "object") return absolute(first.url ?? first.contentUrl, base);
  return absolute(first, base);
}
var isType = (node, name) => [node["@type"]].flat().some((t) => typeof t === "string" && t.replace(/^.*[/:]/, "") === name);
function mediaObjects(doc) {
  const out = [];
  const seen = /* @__PURE__ */ new Set();
  const walk = (node, depth) => {
    if (!node || typeof node !== "object" || seen.has(node) || depth > 8) return;
    seen.add(node);
    if (Array.isArray(node)) return node.forEach((n) => walk(n, depth + 1));
    const obj = node;
    if (isType(obj, "VideoObject") || isType(obj, "AudioObject")) out.push(obj);
    for (const value of Object.values(obj)) walk(value, depth + 1);
  };
  walk(doc, 0);
  return out;
}
function pageCandidates(scan) {
  const base = scan.pageUrl;
  const found = /* @__PURE__ */ new Map();
  const add = (c) => {
    if (!c || found.size >= MAX_CANDIDATES) return;
    const prev = Object.entries(found.get(c.url) ?? {}).filter(([, v]) => v !== void 0);
    found.set(c.url, { ...c, ...Object.fromEntries(prev) });
  };
  for (const text2 of scan.jsonLd) {
    let doc;
    try {
      doc = JSON.parse(text2);
    } catch {
      continue;
    }
    for (const obj of mediaObjects(doc)) {
      const url = absolute(obj.contentUrl, base);
      if (!url) continue;
      add({
        url,
        title: typeof obj.name === "string" ? obj.name.trim() || void 0 : void 0,
        thumbnail: imageUrl(obj.thumbnailUrl ?? obj.thumbnail ?? obj.image, base),
        durationSec: seconds(obj.duration),
        mime: typeof obj.encodingFormat === "string" && obj.encodingFormat.includes("/") ? obj.encodingFormat.toLowerCase() : void 0
      });
    }
  }
  const meta = scan.metas.map((m) => ({ key: m.key.toLowerCase(), value: m.value }));
  for (let i = 0; i < meta.length; i++) {
    const { key, value } = meta[i];
    if (key !== "og:video" && key !== "og:video:url" && key !== "og:video:secure_url" && key !== "twitter:player:stream") continue;
    const typeKey = key === "twitter:player:stream" ? "twitter:player:stream:content_type" : "og:video:type";
    let mime;
    for (let j = i + 1; j < meta.length && j < i + 8; j++) {
      if (meta[j].key === typeKey) {
        mime = meta[j].value.toLowerCase();
        break;
      }
      if (meta[j].key === key) break;
    }
    if (mime && NOT_MEDIA_TYPES.test(mime)) continue;
    const url = absolute(value, base);
    if (url) add({ url, mime });
  }
  for (const src of scan.videoSrcs) {
    const url = absolute(src.url, base);
    if (url) add({ url, mime: src.type?.toLowerCase() || void 0 });
  }
  return [...found.values()];
}
function dailymotionId(pageUrl) {
  try {
    const u = new URL(pageUrl);
    if (u.hostname !== "dailymotion.com" && !u.hostname.endsWith(".dailymotion.com")) return void 0;
    const id = /^\/(?:embed\/)?video\/(x[a-z0-9]+)/i.exec(u.pathname)?.[1] ?? u.searchParams.get("video") ?? void 0;
    return id && /^x[a-z0-9]+$/i.test(id) ? id : void 0;
  } catch {
    return void 0;
  }
}
function isPrivateHost(hostname) {
  const host = hostname.toLowerCase().replace(/^\[|\]$/g, "").replace(/\.$/, "");
  if (host === "localhost" || host.endsWith(".localhost") || host.endsWith(".local")) return true;
  const v4 = /^(\d{1,3})\.(\d{1,3})\.\d{1,3}\.\d{1,3}$/.exec(host);
  if (v4) {
    const [a, b] = [Number(v4[1]), Number(v4[2])];
    return a === 0 || a === 10 || a === 127 || a === 169 && b === 254 || a === 172 && b >= 16 && b <= 31 || a === 192 && b === 168 || a === 100 && b >= 64 && b <= 127;
  }
  if (host.includes(":")) return host === "::" || host === "::1" || /^f[cd]/.test(host) || /^fe[89ab]/.test(host) || /^::ffff:/.test(host);
  return false;
}
function probeCredentials(candidateUrl, pageUrl) {
  let target;
  let page;
  try {
    target = new URL(candidateUrl);
    page = new URL(pageUrl);
  } catch {
    return void 0;
  }
  if (isPrivateHost(target.hostname) && !isPrivateHost(page.hostname)) return void 0;
  const own = page.hostname.replace(/^www\./, "");
  const sameSite = target.protocol === page.protocol && (target.hostname === own || target.hostname.endsWith(`.${own}`) || target.hostname === page.hostname);
  return sameSite ? "include" : "omit";
}

// src/sw/page-probe.ts
var CHECK_TIMEOUT_MS = 1e4;
function scanFrame() {
  const abs = (u) => u && !u.startsWith("blob:") && !u.startsWith("data:") ? u : void 0;
  const videoSrcs = [];
  for (const v of document.querySelectorAll("video, audio")) {
    const own = abs(v.getAttribute("src"));
    if (own) videoSrcs.push({ url: own });
    for (const s of v.querySelectorAll("source")) {
      const url = abs(s.getAttribute("src"));
      if (url) videoSrcs.push({ url, type: s.getAttribute("type") ?? void 0 });
    }
  }
  return {
    pageUrl: location.href,
    jsonLd: [...document.querySelectorAll('script[type="application/ld+json"]')].map((s) => s.textContent ?? "").slice(0, 20),
    metas: [...document.querySelectorAll("meta[content]")].map((m) => ({ key: m.getAttribute("property") ?? m.getAttribute("name") ?? "", value: m.getAttribute("content") ?? "" })).filter((m) => /^(og:|twitter:)/i.test(m.key)),
    videoSrcs: videoSrcs.slice(0, 20)
  };
}
async function scanTab(tabId, seen) {
  try {
    const results = await chrome.scripting.executeScript({ target: { tabId, allFrames: true }, func: scanFrame });
    const out = [];
    for (const r of results) {
      if (!r.result) continue;
      for (const candidate of pageCandidates(r.result)) {
        if (seen.has(candidate.url)) continue;
        seen.add(candidate.url);
        out.push({ candidate, pageUrl: r.result.pageUrl, frameId: r.frameId });
      }
      const id = dailymotionId(r.result.pageUrl);
      if (id && !seen.has(`dailymotion:${id}`)) {
        seen.add(`dailymotion:${id}`);
        const candidate = await dailymotionStream(id);
        if (candidate) out.push({ candidate, pageUrl: r.result.pageUrl, frameId: r.frameId });
      }
    }
    return out;
  } catch {
    return [];
  }
}
async function dailymotionStream(id) {
  try {
    const res = await fetch(`https://www.dailymotion.com/player/metadata/video/${id}`, { cache: "no-store", signal: AbortSignal.timeout(CHECK_TIMEOUT_MS) });
    if (!res.ok) return void 0;
    const info = await res.json();
    const stream = info.qualities?.auto?.find((q) => typeof q.url === "string" && /mpegurl/i.test(String(q.type)));
    if (!stream) return void 0;
    const thumbs = info.thumbnails ?? {};
    const thumbnail = ["720", "480", "360"].map((k) => thumbs[k]).find((t) => typeof t === "string");
    return {
      url: stream.url,
      title: typeof info.title === "string" ? info.title.trim() || void 0 : void 0,
      thumbnail,
      durationSec: typeof info.duration === "number" && info.duration > 0 ? info.duration : void 0,
      mime: "application/x-mpegurl"
    };
  } catch {
    return void 0;
  }
}
async function checkCandidate(candidate, pageUrl) {
  const credentials = probeCredentials(candidate.url, pageUrl);
  if (!credentials) return void 0;
  const sent = { referer: pageUrl };
  const rules = await installReplay([candidate.url], sent);
  try {
    const res = await fetch(candidate.url, {
      headers: { range: "bytes=0-0" },
      credentials,
      cache: "no-store",
      signal: AbortSignal.timeout(CHECK_TIMEOUT_MS)
    });
    void res.body?.cancel();
    const responseHeaders = [...res.headers].map(([name, value]) => ({ name, value }));
    const found = classify({ url: res.url || candidate.url, type: "media", statusCode: res.status, responseHeaders });
    return found ? { candidate, found, pageUrl } : void 0;
  } catch {
    return void 0;
  } finally {
    await removeReplay(rules);
  }
}

// src/shared/format.ts
function formatBytes(bytes) {
  if (bytes === void 0 || !Number.isFinite(bytes)) return "";
  if (bytes < 1024) return `${bytes} B`;
  const units = ["KB", "MB", "GB", "TB"];
  let v = bytes / 1024;
  let i = 0;
  while (v >= 1024 && i < units.length - 1) {
    v /= 1024;
    i++;
  }
  return `${v >= 100 ? v.toFixed(0) : v.toFixed(1)} ${units[i]}`;
}

// src/sw/x-post.ts
function findXPost(mediaKey, statusId) {
  const video = [...document.querySelectorAll("video")].find((v) => v.poster.includes(`/${mediaKey}`));
  const post2 = video?.closest("article");
  if (!video || !post2) return null;
  const text2 = (el) => el?.textContent?.replace(/\s+/g, " ").trim() || void 0;
  const profile = [...post2.querySelectorAll("a[href]")].find(
    (a) => /^\/\w{1,15}$/.test(a.getAttribute("href") ?? "") && text2(a) && !text2(a).startsWith("@")
  );
  const author = text2(post2.querySelector('[data-testid="User-Name"] span')) ?? text2(profile);
  const blocks = [...post2.querySelectorAll('div[dir="auto"]')].filter((d) => !d.querySelector('div[dir="auto"]') && !d.closest("a")).map(text2).filter((t) => !!t && t !== author);
  const body = text2(post2.querySelector('[data-testid="tweetText"]')) ?? blocks.sort((a, b) => b.length - a.length)[0];
  const main = post2.getAttribute("tabindex") === "-1" || statusId !== null && post2.querySelector(`a[href$="/status/${statusId}"], a[href$="in_reply_to=${statusId}"]`) !== null;
  const posts = [...document.querySelectorAll("article")];
  return {
    title: [author, body?.slice(0, 100)].filter(Boolean).join(": ") || void 0,
    thumbnail: video.poster || void 0,
    rank: main ? 0 : posts.indexOf(post2) + 1
  };
}

// src/sw/sites.ts
var CHECK_TIMEOUT_MS2 = 8e3;
async function fileSize(url) {
  try {
    const res = await fetch(url, { headers: { range: "bytes=0-0" }, cache: "no-store", signal: AbortSignal.timeout(CHECK_TIMEOUT_MS2) });
    void res.body?.cancel();
    if (res.status !== 206 && res.status !== 200) return void 0;
    const total = /\/(\d+)\s*$/.exec(res.headers.get("content-range") ?? "")?.[1] ?? res.headers.get("content-length");
    return total ? Number(total) : void 0;
  } catch {
    return void 0;
  }
}
var TWITCH_CLIP = /^(https:\/\/[^/]+\.cloudfront\.net\/nauth\/[^?]+\/)(\d{3,4})(\/index\.mp4\?.*)$/;
var TWITCH_HEIGHTS = [1080, 720, 480, 360];
async function twitchClip(item) {
  const m = item.type === "http" ? TWITCH_CLIP.exec(item.url) : null;
  if (!m) return void 0;
  const [, head, , tail] = m;
  const sizes = await Promise.all(TWITCH_HEIGHTS.map((h) => fileSize(`${head}${h}${tail}`)));
  const variants = TWITCH_HEIGHTS.flatMap(
    (height, i) => sizes[i] ? [{ id: String(height), label: `${height}p \xB7 ${formatBytes(sizes[i])}`, height, url: `${head}${height}${tail}`, sizeBytes: sizes[i] }] : []
  );
  return variants.length > 1 ? { variants } : void 0;
}
function xMediaKey(url) {
  return /video\.twimg\.com\/(?:amplify_video|ext_tw_video)\/(\d+)\//.exec(url)?.[1] ?? /video\.twimg\.com\/tweet_video\/([\w-]+)\.mp4/.exec(url)?.[1];
}
async function xPost(item) {
  const key = xMediaKey(item.url);
  if (!key) return void 0;
  const statusId = /\/status\/(\d+)/.exec(item.pageUrl)?.[1] ?? null;
  const [res] = await chrome.scripting.executeScript({ target: { tabId: item.tabId }, func: findXPost, args: [key, statusId] });
  return res?.result ?? void 0;
}
var EXTRACTORS = [twitchClip, xPost];
async function enrich(item) {
  for (const extract of EXTRACTORS) {
    try {
      const extra = await extract(item);
      if (extra) return extra;
    } catch {
    }
  }
  return {};
}

// src/sw/registry.ts
var MAX_PER_TYPE = 10;
var DASH_SEGMENT_BYTES = 20 * 1024 * 1024;
var WRITE_DELAY_MS = 300;
var NEW_VIDEO_GAP_MS = 15e3;
function isLikelyDashSegment(item) {
  return item.type === "http" && (item.sizeBytes ?? 0) < DASH_SEGMENT_BYTES;
}
function isMirror(a, b) {
  if (a.type !== b.type || a.type !== "hls" && a.type !== "dash") return false;
  try {
    const [ua, ub] = [new URL(a.url), new URL(b.url)];
    return ua.host !== ub.host && ua.pathname === ub.pathname && ua.pathname.split("/").filter(Boolean).length > 1;
  } catch {
    return false;
  }
}
function isSameStream(a, b) {
  if (a.type !== b.type || a.type !== "hls" && a.type !== "dash") return false;
  try {
    const [ua, ub] = [new URL(a.url), new URL(b.url)];
    return ua.host === ub.host && ua.pathname === ub.pathname && ua.pathname.split("/").filter(Boolean).length > 1;
  } catch {
    return false;
  }
}
var isPlayback = (m) => m.sourceKind === "sniffer" && m.type !== "mse";
function mergeMedia(list2, item, busy = /* @__PURE__ */ new Set()) {
  const existing = list2.findIndex((m) => m.id === item.id);
  if (existing >= 0) {
    const old = list2[existing];
    const merged = {
      ...old,
      sizeBytes: old.sizeBytes ?? item.sizeBytes,
      supportsRanges: old.supportsRanges || item.supportsRanges,
      serverFilename: old.serverFilename ?? item.serverFilename,
      // The player's own request carries the cookies a page-declared URL lacks.
      sentHeaders: old.sourceKind === "page" && item.sourceKind === "sniffer" ? item.sentHeaders : Object.keys(old.sentHeaders).length ? old.sentHeaders : item.sentHeaders,
      sourceKind: old.sourceKind === "sniffer" || item.sourceKind === "sniffer" ? "sniffer" : "page",
      title: old.title ?? item.title,
      thumbnail: old.thumbnail ?? item.thumbnail,
      rank: old.rank ?? item.rank,
      variants: old.variants ?? item.variants,
      childUrls: old.childUrls ?? item.childUrls,
      durationSec: old.durationSec ?? item.durationSec,
      isLive: old.isLive ?? item.isLive,
      subtitles: old.subtitles ?? item.subtitles,
      hasDrm: old.hasDrm || item.hasDrm
    };
    for (const key of ["variants", "childUrls", "durationSec", "isLive", "subtitles", "title", "thumbnail", "rank"]) {
      if (merged[key] === void 0) delete merged[key];
    }
    const changed = JSON.stringify(merged) !== JSON.stringify(old);
    if (!changed) return { list: list2, changed: false };
    const next2 = list2.slice();
    next2[existing] = merged;
    return { list: next2, changed: true };
  }
  const isStream = (m) => (m.type === "hls" || m.type === "dash") && m.variants?.length !== 0;
  if (item.type === "mse" && !item.recording && list2.some(isStream)) return { list: list2, changed: false };
  if (isStream(item)) list2 = list2.filter((m) => m.type !== "mse" || m.recording);
  if (item.sourceKind === "page") {
    const played = list2.findIndex((m) => m.sourceKind === "sniffer" && isSameStream(m, item));
    if (played >= 0) {
      const old = list2[played];
      const named = { ...old, title: old.title ?? item.title, thumbnail: old.thumbnail ?? item.thumbnail };
      for (const key of ["title", "thumbnail"]) if (named[key] === void 0) delete named[key];
      if (JSON.stringify(named) === JSON.stringify(old)) return { list: list2, changed: false };
      const next2 = list2.slice();
      next2[played] = named;
      return { list: next2, changed: true };
    }
  } else {
    const declared = list2.find((m) => m.sourceKind === "page" && !busy.has(m.id) && isSameStream(m, item));
    if (declared) {
      list2 = list2.filter((m) => m !== declared);
      item = { ...item, title: item.title ?? declared.title, thumbnail: item.thumbnail ?? declared.thumbnail };
      for (const key of ["title", "thumbnail"]) if (item[key] === void 0) delete item[key];
    }
  }
  if (list2.some((m) => isMirror(m, item))) return { list: list2, changed: false };
  const hasDash = list2.some((m) => m.type === "dash");
  if (hasDash && isLikelyDashSegment(item)) return { list: list2, changed: false };
  if (list2.some((m) => m.childUrls?.includes(item.url))) return { list: list2, changed: false };
  const before = item.detectedAt - NEW_VIDEO_GAP_MS;
  if (isPlayback(item) && list2.some((m) => isPlayback(m) && m.detectedAt <= before)) {
    list2 = list2.filter((m) => m.detectedAt > before || m.recording || busy.has(m.id));
  }
  let next = [...list2, item];
  if (item.type === "dash") next = next.filter((m) => !isLikelyDashSegment(m));
  if (item.childUrls?.length) {
    const children = new Set(item.childUrls);
    next = next.filter((m) => !children.has(m.url));
  }
  const sameType = next.filter((m) => m.type === item.type);
  if (sameType.length > MAX_PER_TYPE) {
    const drop = new Set(sameType.slice(0, sameType.length - MAX_PER_TYPE).map((m) => m.id));
    next = next.filter((m) => !drop.has(m.id));
  }
  return { list: next, changed: true };
}
var Registry = class {
  constructor(onChange = () => {
  }) {
    this.onChange = onChange;
  }
  onChange;
  tabs = /* @__PURE__ */ new Map();
  dirty = /* @__PURE__ */ new Set();
  removed = /* @__PURE__ */ new Set();
  timer;
  async get(tabId) {
    const cached = this.tabs.get(tabId);
    if (cached) return cached;
    const key = storageKeys.tab(tabId);
    const stored = (await chrome.storage.session.get(key))[key];
    if (stored && !this.tabs.has(tabId)) this.tabs.set(tabId, stored);
    return this.tabs.get(tabId);
  }
  /** Returns true when the item is new or changed something. */
  async add(item, busy) {
    const tab = await this.get(item.tabId) ?? { tabId: item.tabId, pageUrl: item.pageUrl, media: [] };
    const { list: list2, changed } = mergeMedia(tab.media, item, busy);
    if (!changed) return false;
    this.put({ ...tab, media: list2 });
    return true;
  }
  async update(tabId, patch) {
    const tab = await this.get(tabId);
    if (tab) this.put({ ...tab, ...patch });
  }
  async findMedia(tabId, mediaId) {
    const tab = await this.get(tabId);
    const item = tab?.media.find((m) => m.id === mediaId);
    return tab && item ? { tab, item } : void 0;
  }
  clear(tabId) {
    this.tabs.delete(tabId);
    this.dirty.delete(tabId);
    this.removed.add(tabId);
    this.onChange(void 0, tabId);
    this.schedule();
  }
  put(tab) {
    this.tabs.set(tab.tabId, tab);
    this.removed.delete(tab.tabId);
    this.dirty.add(tab.tabId);
    this.onChange(tab, tab.tabId);
    this.schedule();
  }
  schedule() {
    if (this.timer) return;
    this.timer = setTimeout(() => void this.flush(), WRITE_DELAY_MS);
  }
  async flush() {
    this.timer = void 0;
    const writes = {};
    for (const id of this.dirty) {
      const tab = this.tabs.get(id);
      if (tab) writes[storageKeys.tab(id)] = tab;
    }
    const removes = [...this.removed].map(storageKeys.tab);
    this.dirty.clear();
    this.removed.clear();
    if (Object.keys(writes).length) await chrome.storage.session.set(writes);
    if (removes.length) await chrome.storage.session.remove(removes);
  }
};

// src/sw/license.ts
var CHECK_TIMEOUT_MS3 = 5e3;
async function loadPaidAt() {
  const stored = (await chrome.storage.sync.get(storageKeys.paidAt))[storageKeys.paidAt];
  return typeof stored === "number" ? stored : void 0;
}
async function loadPaidSession() {
  const stored = (await chrome.storage.sync.get(storageKeys.paidSession))[storageKeys.paidSession];
  return typeof stored === "string" ? stored : void 0;
}
async function refreshLicense(sessionId) {
  const id = await getInstallId();
  const kept = await loadPaidSession();
  const session = sessionId ?? kept;
  const url = new URL(LICENSE_URL);
  url.searchParams.set("id", id);
  if (session) url.searchParams.set("session", session);
  const now = Date.now();
  let license = await loadLicense();
  let answered = false;
  try {
    const res = await fetch(url, { credentials: "omit", cache: "no-store", signal: AbortSignal.timeout(CHECK_TIMEOUT_MS3) });
    const fresh = res.ok ? parseLicense(await res.json(), now) : void 0;
    if (fresh) {
      license = fresh;
      answered = true;
    }
  } catch {
  }
  const stored = (await chrome.storage.local.get(storageKeys.ads))[storageKeys.ads];
  const adFree = isAdFree(license, now);
  await chrome.storage.local.set({
    [storageKeys.license]: license,
    [storageKeys.ads]: { ...emptyAdState, ...stored, adFree, ...adFree ? { due: void 0 } : {} }
  });
  if (answered) {
    if (adFree && sessionId && sessionId !== kept) await chrome.storage.sync.set({ [storageKeys.paidSession]: sessionId });
    if (!adFree && kept) await chrome.storage.sync.remove(storageKeys.paidSession);
    const paidAt = await loadPaidAt();
    const next = nextPaidAt(paidAt, adFree, now);
    if (next !== paidAt) await (next === void 0 ? chrome.storage.sync.remove(storageKeys.paidAt) : chrome.storage.sync.set({ [storageKeys.paidAt]: next }));
  }
  return adFree;
}
async function refreshLicenseIfStale() {
  const [license, paidAt] = await Promise.all([loadLicense(), loadPaidAt()]);
  if (shouldCheck(license, paidAt, Date.now())) await refreshLicense();
}
function watchThanksPage() {
  chrome.tabs.onUpdated.addListener((_tabId, change) => {
    if (!change.url?.startsWith(`${SITE_ORIGIN}${THANKS_PATH}`)) return;
    const session = new URL(change.url).searchParams.get("session_id") ?? void 0;
    void refreshLicense(session);
  });
  chrome.storage.sync.onChanged.addListener((changes) => {
    if (typeof changes[storageKeys.paidAt]?.newValue === "number") void refreshLicenseIfStale();
  });
}

// src/shared/open-mode.ts
async function applyOpenMode(sidePanel) {
  await chrome.action.setPopup({ popup: sidePanel ? "" : "popup.html" });
  await chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: sidePanel }).catch(() => {
  });
}

// src/sw/side-panel.ts
function watchSidePanelSetting() {
  void loadSettings().then((s) => applyOpenMode(s.sidePanel));
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && storageKeys.settings in changes) void loadSettings().then((s) => applyOpenMode(s.sidePanel));
  });
}

// src/sw/main.ts
var RESCAN_DELAY_MS = 1500;
var RESCAN_AFTER_LOAD_MS = 4e3;
var PLAYER_GRACE_MS = 3e3;
var SNIFF_TYPES = ["xmlhttprequest", "media", "sub_frame", "other"];
var BADGE_COLOR = "#C8781E";
var headerCache = new HeaderCache();
var registry = new Registry(updateBadge);
var downloads = new Downloads();
var metaRequested = /* @__PURE__ */ new Set();
var pendingDrm = /* @__PURE__ */ new Map();
var handling = /* @__PURE__ */ new Map();
function track(tabId, work) {
  const set = handling.get(tabId) ?? /* @__PURE__ */ new Set();
  handling.set(tabId, set);
  set.add(work);
  void work.finally(() => {
    set.delete(work);
    if (!set.size && handling.get(tabId) === set) handling.delete(tabId);
  });
}
function updateBadge(tab, tabId) {
  const count2 = tab?.media.length ?? 0;
  chrome.action.setBadgeText({ tabId, text: count2 ? String(count2) : "" }).catch(() => {
  });
  chrome.action.setBadgeBackgroundColor({ tabId, color: BADGE_COLOR }).catch(() => {
  });
}
chrome.webRequest.onSendHeaders.addListener(
  (details) => headerCache.put(details.requestId, replayableHeaders(details.requestHeaders)),
  { urls: ["<all_urls>"], types: SNIFF_TYPES },
  ["requestHeaders", "extraHeaders"]
);
chrome.webRequest.onResponseStarted.addListener(
  (details) => onResponse(details),
  { urls: ["<all_urls>"], types: SNIFF_TYPES },
  ["responseHeaders", "extraHeaders"]
);
function onResponse(details) {
  if (details.tabId < 0) return;
  const found = classify({
    url: details.url,
    type: details.type,
    statusCode: details.statusCode,
    responseHeaders: details.responseHeaders ?? [],
    initiator: details.initiator
  });
  if (!found) return;
  const earlier = [...handling.get(details.tabId) ?? []];
  track(details.tabId, handleResponse(details, found, earlier));
}
async function handleResponse(details, found, earlier) {
  const tab = await chrome.tabs.get(details.tabId).catch(() => void 0);
  if (!tab) return;
  await list({
    tabId: details.tabId,
    url: details.url,
    found,
    sentHeaders: headerCache.get(details.requestId) ?? {},
    pageUrl: tab.url ?? details.initiator ?? "",
    frame: { tabId: details.tabId, frameId: details.frameId },
    earlier,
    extra: { sourceKind: "sniffer" }
  });
}
async function list(input) {
  const { tabId, url, found, sentHeaders } = input;
  const known = await registry.get(tabId);
  const isStream = found.type !== "http";
  if (known?.media.some((m) => m.childUrls?.includes(url) || isStream && m.url === url)) return;
  const streamDetails = found.type === "hls" ? await probeHls(url, sentHeaders, input.frame) : found.type === "dash" ? await probeDash(url, sentHeaders, input.frame) : {};
  if (streamDetails === null) return;
  await Promise.allSettled(input.earlier);
  const now = await registry.get(tabId);
  if (now?.media.some((m) => m.childUrls?.includes(url))) return;
  const item = {
    id: hash53(url),
    type: found.type,
    url,
    tabId,
    pageUrl: input.pageUrl,
    mime: found.mime,
    ext: found.ext,
    sizeBytes: found.sizeBytes,
    supportsRanges: found.supportsRanges,
    serverFilename: found.serverFilename,
    sentHeaders,
    hasDrm: false,
    detectedAt: Date.now(),
    ...input.extra,
    ...streamDetails
  };
  if (item.durationSec === void 0) delete item.durationSec;
  for (const [key, value] of Object.entries(await enrich(item))) if (value !== void 0) Object.assign(item, { [key]: value });
  const added = await registry.add(item, await downloads.busyMedia(tabId));
  const drm = pendingDrm.get(tabId);
  if (added && drm) {
    pendingDrm.delete(tabId);
    await registry.update(tabId, { drmKeySystem: drm });
  }
  if (added && !metaRequested.has(tabId)) {
    metaRequested.add(tabId);
    void readPageMeta(tabId);
  }
}
var scanned = /* @__PURE__ */ new Map();
async function scanPage(tabId) {
  const seen = scanned.get(tabId) ?? /* @__PURE__ */ new Set();
  scanned.set(tabId, seen);
  const candidates = await scanTab(tabId, seen);
  const checked = await Promise.all(candidates.map(async (c) => ({ hit: await checkCandidate(c.candidate, c.pageUrl), frameId: c.frameId })));
  for (const { hit, frameId } of checked) {
    if (!hit) continue;
    const { candidate, found, pageUrl } = hit;
    const earlier = [...handling.get(tabId) ?? []];
    track(
      tabId,
      list({
        tabId,
        url: candidate.url,
        found,
        sentHeaders: { referer: pageUrl },
        pageUrl,
        frame: { tabId, frameId },
        earlier,
        extra: { sourceKind: "page", title: candidate.title, thumbnail: candidate.thumbnail, durationSec: candidate.durationSec }
      })
    );
  }
}
chrome.webNavigation.onCompleted.addListener((d) => {
  if (d.frameId !== 0) return;
  void scanPage(d.tabId);
  setTimeout(() => void scanPage(d.tabId), RESCAN_AFTER_LOAD_MS);
});
chrome.webNavigation.onHistoryStateUpdated.addListener((d) => {
  if (d.frameId === 0) setTimeout(() => void scanPage(d.tabId), RESCAN_DELAY_MS);
});
async function readPageMeta(tabId) {
  try {
    const [res] = await chrome.scripting.executeScript({
      target: { tabId },
      func: () => {
        const meta = (sel) => document.querySelector(sel)?.getAttribute("content")?.trim() || void 0;
        const abs = (u) => {
          try {
            return u ? new URL(u, location.href).href : void 0;
          } catch {
            return void 0;
          }
        };
        return {
          docTitle: document.title.trim(),
          ogTitle: meta('meta[property="og:title"]') || meta('meta[name="twitter:title"]'),
          siteName: meta('meta[property="og:site_name"]'),
          thumbnail: abs(document.querySelector("video[poster]")?.getAttribute("poster")) ?? abs(meta('meta[property="og:image"]')) ?? abs(meta('meta[name="twitter:image"]')) ?? abs(document.querySelector('link[rel="image_src"]')?.getAttribute("href")),
          pageUrl: location.href,
          // Captions the page attaches to its videos with <track>.
          tracks: [...document.querySelectorAll("video track[src]")].filter((t) => !t.kind || t.kind === "subtitles" || t.kind === "captions").map((t) => ({ url: abs(t.getAttribute("src")), label: t.label, lang: t.srclang })).filter((t) => t.url)
        };
      }
    });
    if (res?.result) {
      const { tracks, docTitle, ogTitle, siteName, ...meta } = res.result;
      const title = cleanTitle({ docTitle, ogTitle, siteName, host: new URL(meta.pageUrl).hostname });
      const subtitles = tracks.map((t, i) => ({
        id: `page-${i}`,
        label: t.label || t.lang || `Subtitles ${i + 1}`,
        lang: t.lang || void 0,
        source: { kind: "file", url: t.url }
      }));
      await registry.update(tabId, { ...meta, title, ...subtitles.length ? { subtitles } : {} });
    }
  } catch {
  }
}
chrome.webNavigation.onBeforeNavigate.addListener((d) => {
  if (d.frameId !== 0) return;
  metaRequested.delete(d.tabId);
  pendingDrm.delete(d.tabId);
  scanned.delete(d.tabId);
  registry.clear(d.tabId);
});
chrome.tabs.onRemoved.addListener((tabId) => {
  metaRequested.delete(tabId);
  pendingDrm.delete(tabId);
  scanned.delete(tabId);
  registry.clear(tabId);
});
chrome.tabs.onUpdated.addListener((tabId, change) => {
  if (change.title) void registry.get(tabId).then((t) => t && readPageMeta(tabId));
});
function fromExtensionPage(sender) {
  try {
    return sender.id === chrome.runtime.id && new URL(sender.url ?? "").protocol === "chrome-extension:";
  } catch {
    return false;
  }
}
var PAGE_REPORTS = /* @__PURE__ */ new Set(["page-drm", "page-mse"]);
chrome.runtime.onMessage.addListener((msg, sender, respond) => {
  if (!msg || typeof msg !== "object") return;
  if ("target" in msg) {
    if (msg.target !== "service-worker" || !fromExtensionPage(sender)) return;
    downloads.onWorkerMessage(msg.message).finally(() => respond(true));
    return true;
  }
  if (!PAGE_REPORTS.has(msg.kind) && !fromExtensionPage(sender)) return;
  handle(msg, sender).then(respond, (err) => respond({ ok: false, error: err instanceof Error ? err.message : String(err) }));
  return true;
});
async function handle(cmd, sender) {
  switch (cmd.kind) {
    case "download": {
      const found = await registry.findMedia(cmd.payload.tabId, cmd.payload.mediaId);
      if (!found) return { ok: false, error: "That video is no longer on this page. Reload and try again." };
      const jobId = await downloads.start(found.tab, found.item, cmd.payload.filename, cmd.payload.variantId, cmd.payload.subtitleId);
      return { ok: true, jobId };
    }
    case "cancel":
      await downloads.cancel(cmd.payload.jobId);
      return { ok: true };
    case "stop":
      await downloads.stop(cmd.payload.jobId);
      return { ok: true };
    case "page-drm": {
      const tabId = sender.tab?.id;
      if (tabId === void 0) return { ok: false, error: "Not from a tab" };
      const tab = await registry.get(tabId);
      if (tab) await registry.update(tabId, { drmKeySystem: cmd.payload.keySystem });
      else pendingDrm.set(tabId, cmd.payload.keySystem);
      return { ok: true };
    }
    case "page-mse": {
      const tabId = sender.tab?.id;
      if (tabId === void 0 || sender.frameId === void 0) return { ok: false, error: "Not from a tab" };
      const frameUrl = sender.url ?? sender.tab?.url ?? "";
      const id = playerId(tabId, sender.frameId, frameUrl);
      const armed = await downloads.claimArmed(tabId, sender.frameId, id, sender.tab?.url ?? frameUrl);
      void listPlayer(tabId, sender.frameId, frameUrl, cmd.payload.mime, !armed);
      return armed ? { ok: true, jobId: armed.jobId } : { ok: true };
    }
    case "capture-job": {
      const from = sender.url ? new URL(sender.url) : void 0;
      if (sender.id !== chrome.runtime.id || from?.protocol !== "chrome-extension:" || from.pathname !== "/capture.html")
        return { ok: false, error: "Not the capture page" };
      const job = await downloads.claimCapture(cmd.payload.jobId);
      return job ? { ok: true, filename: job.filename, saveAs: job.saveAs } : { ok: false, error: "No such recording" };
    }
    case "clear-tab":
      registry.clear(cmd.payload.tabId);
      return { ok: true };
    case "scan-tab":
      void scanPage(cmd.payload.tabId);
      return { ok: true };
    case "check-license":
      await refreshLicense();
      return { ok: true };
    case "ad-gate":
      await refreshLicenseIfStale().catch(() => {
      });
      return { ok: true, ad: await gateDownload() };
  }
}
var playerId = (tabId, frameId, frameUrl) => hash53(`mse:${tabId}:${frameId}:${frameUrl}`);
async function listPlayer(tabId, frameId, frameUrl, mime, grace) {
  if (grace) await new Promise((r) => setTimeout(r, PLAYER_GRACE_MS));
  await Promise.allSettled([...handling.get(tabId) ?? []]);
  const tab = await chrome.tabs.get(tabId).catch(() => void 0);
  if (!tab) return;
  const audioOnly = mime.startsWith("audio/");
  const added = await registry.add({
    id: playerId(tabId, frameId, frameUrl),
    type: "mse",
    url: frameUrl,
    tabId,
    pageUrl: tab.url ?? frameUrl,
    mime: audioOnly ? "audio/mp4" : "video/mp4",
    ext: audioOnly ? "m4a" : "mp4",
    supportsRanges: false,
    sentHeaders: {},
    hasDrm: false,
    detectedAt: Date.now(),
    sourceKind: "sniffer",
    frameId,
    recording: !grace || void 0
  });
  if (added && !metaRequested.has(tabId)) {
    metaRequested.add(tabId);
    void readPageMeta(tabId);
  }
}
watchSidePanelSetting();
watchThanksPage();
chrome.runtime.onStartup.addListener(() => {
  void clearStaleRules();
  void refreshLicenseIfStale();
  void retrySignUp().catch(() => {
  });
});
chrome.runtime.onInstalled.addListener((details) => {
  void clearStaleRules();
  if (details.reason === "update") void loadAsks().then((asks) => skipActivationIfSavedBefore(details.previousVersion, asks.saved)).catch(() => {
  });
  if (details.reason === "install") void noteInstalled().catch(() => {
  });
});
//# sourceMappingURL=sw.js.map
