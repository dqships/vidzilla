// src/offscreen/offscreen.ts
var worker = new Worker("worker.js", { type: "module" });
async function relay(message, attempt = 0) {
  const envelope = { target: "service-worker", message };
  try {
    await chrome.runtime.sendMessage(envelope);
  } catch {
    if (message.type !== "progress" && attempt < 10) {
      setTimeout(() => void relay(message, attempt + 1), 1e3);
    }
  }
}
worker.onmessage = (e) => void relay(e.data);
chrome.runtime.onMessage.addListener((msg, sender, respond) => {
  if (msg?.target !== "offscreen" || sender.id !== chrome.runtime.id || !sender.url?.startsWith(chrome.runtime.getURL(""))) return;
  worker.postMessage(msg.message);
  respond(true);
});
//# sourceMappingURL=offscreen.js.map
