// src/shared/format.ts
function formatBytes(bytes) {
  if (bytes === void 0 || !Number.isFinite(bytes)) return "";
  if (bytes < 1024) return `${bytes} B`;
  const units = ["KB", "MB", "GB", "TB"];
  let v = bytes / 1024;
  let i = 0;
  while (v >= 1024 && i < units.length - 1) {
    v /= 1024;
    i++;
  }
  return `${v >= 100 ? v.toFixed(0) : v.toFixed(1)} ${units[i]}`;
}
function formatDuration(seconds) {
  if (seconds === void 0 || !Number.isFinite(seconds) || seconds <= 0) return "";
  const total = Math.round(seconds);
  const h = Math.floor(total / 3600);
  const m = Math.floor(total % 3600 / 60);
  const s = String(total % 60).padStart(2, "0");
  return h ? `${h}:${String(m).padStart(2, "0")}:${s}` : `${m}:${s}`;
}

// src/shared/messages.ts
var storageKeys = {
  tab: (tabId2) => `tab:${tabId2}`,
  jobs: "jobs",
  settings: "settings",
  history: "history",
  asks: "asks",
  /** House ad schedule state (shared/ads.ts AdState). */
  ads: "ads",
  /** The ad list last fetched from the website, with when. */
  adFeed: "adFeed",
  /** The ad-free license as the website last answered (shared/license.ts). */
  license: "license",
  /** This install's random ID, in chrome.storage.sync. */
  installId: "installId",
  /** When a copy on this Chrome profile last saw a paid license (ms), in chrome.storage.sync. */
  paidAt: "paidAt",
  /** The checkout that confirmed this profile's purchase, in chrome.storage.sync: sent with each check. */
  paidSession: "paidSession",
  /** What removing the ads costs this install, as the website last said (shared/license.ts). */
  prices: "prices",
  /** When this install's first save was reported to PostHog as `activated` (ms), in chrome.storage.sync (sw/analytics.ts). */
  activatedAt: "activatedAt",
  /** When this install was reported to PostHog as `signed_up` (ms), in chrome.storage.sync (sw/analytics.ts). */
  signedUpAt: "signedUpAt",
  /** True while a fresh install's `signed_up` still has to reach PostHog, in chrome.storage.local (sw/analytics.ts). */
  signUpPending: "signUpPending"
};
function sendCommand(cmd) {
  return chrome.runtime.sendMessage(cmd);
}

// src/shared/naming.ts
function savedExt(item, variant) {
  return variant?.webm ? "webm" : variant?.audioOnly ? "m4a" : item.ext;
}
var RESERVED_WINDOWS = /^(con|prn|aux|nul|com[1-9]|lpt[1-9])$/i;
var MAX_BYTES = 200;
function siteLabel(url) {
  let host;
  try {
    host = new URL(url).hostname;
  } catch {
    return "";
  }
  if (/^[\d.]+$/.test(host) || host.includes(":") || host.startsWith("[")) return host;
  const parts = host.replace(/^www\d*\./, "").split(".");
  if (parts.length === 1) return parts[0] ?? "";
  const secondLevel = parts.at(-2) ?? "";
  const hasCompoundSuffix = parts.length >= 3 && (parts.at(-1) ?? "").length === 2 && /^(co|com|org|net|gov|ac|edu|ne|or)$/.test(secondLevel);
  return (hasCompoundSuffix ? parts.at(-3) : secondLevel) ?? "";
}
function stripExt(name) {
  return name.replace(/\.[a-z0-9]{1,5}$/i, "");
}
function nameFromUrl(url) {
  try {
    const last = new URL(url).pathname.split("/").filter(Boolean).at(-1) ?? "";
    return stripExt(decodeURIComponent(last));
  } catch {
    return "";
  }
}
function isoDate(d) {
  const pad = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}
function expandTemplate(template2, vars) {
  return template2.replace(/([\s_-]*)%([a-z]+)/gi, (whole, sep, key) => {
    const value = vars[key.toLowerCase()];
    if (value === void 0) return whole;
    return value === "" ? "" : sep + value;
  }).replace(/^[\s_-]+|[\s_-]+$/g, "");
}
function truncateBytes(s, maxBytes) {
  const enc = new TextEncoder();
  if (enc.encode(s).length <= maxBytes) return s;
  let out = "";
  for (const ch of s) {
    if (enc.encode(out + ch).length > maxBytes) break;
    out += ch;
  }
  return out;
}
function sanitizeFilename(raw, maxLength = 80) {
  let s = raw.normalize("NFC");
  s = s.replace(/[\u0000-\u001f\u007f]/g, " ");
  s = s.replace(/[<>:"/\\|?*]/g, " ");
  s = s.replace(/\s+/g, " ").replace(/-{2,}/g, "-");
  s = s.replace(/^[\s.]+/, "");
  s = Array.from(s).slice(0, maxLength).join("");
  s = truncateBytes(s, MAX_BYTES);
  s = s.replace(/[\s.]+$/, "");
  if (RESERVED_WINDOWS.test(s)) s += "_";
  return s || "untitled";
}
function buildFilename(input) {
  const title = input.title?.trim() || (input.serverFilename ? stripExt(input.serverFilename) : "") || nameFromUrl(input.mediaUrl);
  const base = expandTemplate(input.template, {
    title,
    hostname: siteLabel(input.pageUrl),
    date: isoDate(input.now ?? /* @__PURE__ */ new Date())
  });
  return `${sanitizeFilename(base, input.maxLength)}.${input.ext}`;
}

// src/shared/settings.ts
var defaultSettings = {
  template: "%title",
  maxLength: 80,
  subfolder: "",
  saveAs: false,
  sidePanel: false
};
async function loadSettings() {
  const stored = (await chrome.storage.local.get(storageKeys.settings))[storageKeys.settings];
  return { ...defaultSettings, ...stored };
}

// src/shared/open-mode.ts
async function applyOpenMode(sidePanel) {
  await chrome.action.setPopup({ popup: sidePanel ? "" : "popup.html" });
  await chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: sidePanel }).catch(() => {
  });
}
async function setOpenMode(sidePanel) {
  await applyOpenMode(sidePanel);
  const settings2 = await loadSettings();
  if (settings2.sidePanel !== sidePanel) await chrome.storage.local.set({ [storageKeys.settings]: { ...settings2, sidePanel } });
}

// src/shared/ads.ts
var emptyAdState = { saved: 0, sinceAd: 0, shownAt: 0, next: 0, adFree: false };
function adWatched(state, elapsedMs) {
  if (!state.due) return state;
  return { ...state, due: { ...state.due, remainingMs: Math.max(0, state.due.remainingMs - elapsedMs) } };
}
function adClosed(state, now) {
  if (!state.due || state.due.remainingMs > 0) return state;
  return { ...state, due: void 0, shownAt: now, sinceAd: 0, next: state.next + 1, adThisSave: true };
}

// src/shared/license.ts
var SITE_ORIGIN = "https://vidzilla.followusai.com";
var UPGRADE_URL = `${SITE_ORIGIN}/upgrade`;
var LICENSE_URL = `${SITE_ORIGIN}/api/license`;
var PRICES_URL = `${SITE_ORIGIN}/api/prices`;
var PRICES_TTL_MS = 6 * 36e5;
var PORTAL_URL = `${SITE_ORIGIN}/api/portal`;
var LICENSE_TTL_MS = 24 * 36e5;
var PAID_ELSEWHERE_RETRY_MS = 10 * 6e4;
var PAID_ELSEWHERE_GRACE_MS = 24 * 36e5;
var noLicense = { adFree: false, checkedAt: 0 };
async function getInstallId() {
  const stored = (await chrome.storage.sync.get(storageKeys.installId))[storageKeys.installId];
  if (typeof stored === "string" && stored) return stored;
  const id = crypto.randomUUID();
  await chrome.storage.sync.set({ [storageKeys.installId]: id });
  return id;
}
async function loadLicense() {
  const stored = (await chrome.storage.local.get(storageKeys.license))[storageKeys.license];
  return { ...noLicense, ...stored };
}
async function upgradeLink(base = UPGRADE_URL) {
  return `${base}?id=${encodeURIComponent(await getInstallId())}`;
}
function isAdFree(license, now) {
  return license.adFree && (license.until == null || license.until > now);
}
function parsePrices(json, now) {
  const j = json && typeof json === "object" ? json : {};
  const ok = (v) => typeof v === "string" && v.length > 0 && v.length <= 40;
  return ok(j.subscription) && ok(j.lifetime) ? { subscription: j.subscription, lifetime: j.lifetime, fetchedAt: now } : void 0;
}
async function loadPrices() {
  return (await chrome.storage.local.get(storageKeys.prices))[storageKeys.prices];
}
async function refreshPrices(now = Date.now()) {
  const cached = await loadPrices();
  if (cached && now - cached.fetchedAt < PRICES_TTL_MS) return cached;
  try {
    const url = new URL(PRICES_URL);
    url.searchParams.set("id", await getInstallId());
    const res = await fetch(url, { credentials: "omit", signal: AbortSignal.timeout(5e3) });
    const fresh = res.ok ? parsePrices(await res.json(), now) : void 0;
    if (fresh) {
      await chrome.storage.local.set({ [storageKeys.prices]: fresh });
      return fresh;
    }
  } catch {
  }
  return cached;
}

// src/ui/ads-view.ts
var TICK_MS = 250;
var SAVE_MS = 1e3;
function bindAd(doc) {
  const section = doc.querySelector("#ad");
  const views = [...doc.querySelectorAll("#settings-view, #saved-view")];
  const icon = section.querySelector(".vz-ad-icon");
  const name = section.querySelector(".vz-ad-name");
  const line = section.querySelector(".vz-ad-line");
  const cta = section.querySelector(".vz-ad-cta");
  const count = section.querySelector(".vz-ad-count");
  const perf = section.querySelector(".vz-ad-perf");
  const remove = section.querySelector(".vz-ad-remove");
  const close = section.querySelector(".vz-ad-close");
  let state = emptyAdState;
  let total = 15e3;
  let upgradeUrl = "";
  let unsaved = 0;
  let lastTick = 0;
  let sinceSave = 0;
  let timer;
  let pending3;
  const visible = () => Boolean(state.due) && Boolean(pending3) && !state.adFree && views.every((v) => v.hidden);
  const remaining = () => Math.max(0, (state.due?.remainingMs ?? 0) - unsaved);
  async function save() {
    if (!unsaved) return;
    const elapsed = unsaved;
    unsaved = 0;
    state = adWatched(state, elapsed);
    const stored = await read();
    await chrome.storage.local.set({ [storageKeys.ads]: adWatched(stored, elapsed) });
  }
  async function read() {
    const data = await chrome.storage.local.get([storageKeys.ads, storageKeys.adFeed]);
    const feed = data[storageKeys.adFeed]?.feed;
    total = (feed?.schedule.seconds ?? 15) * 1e3;
    upgradeUrl = feed?.upgradeUrl ?? "";
    return { ...emptyAdState, ...data[storageKeys.ads] };
  }
  function paint() {
    const left = remaining();
    const seconds = Math.ceil(left / 1e3);
    count.textContent = String(seconds).padStart(2, "0");
    const done = total ? Math.min(1, 1 - left / total) : 1;
    perf.style.setProperty("--vz-perf-value", `${done * 100}%`);
    perf.setAttribute("aria-valuenow", String(Math.round(done * 100)));
    close.disabled = left > 0;
    close.textContent = left > 0 ? `Continue in ${seconds}` : "Continue";
  }
  function tick() {
    const now = performance.now();
    const elapsed = now - lastTick;
    lastTick = now;
    if (!visible() || doc.visibilityState !== "visible") return;
    unsaved = Math.min(unsaved + elapsed, state.due?.remainingMs ?? 0);
    sinceSave += elapsed;
    paint();
    if (sinceSave >= SAVE_MS || remaining() === 0) {
      sinceSave = 0;
      void save();
    }
  }
  function render2() {
    const show = visible();
    section.hidden = !show;
    doc.body.classList.toggle("has-ad", show);
    if (!show || !state.due) {
      clearInterval(timer);
      timer = void 0;
      return;
    }
    const { ad: ad2 } = state.due;
    if (section.dataset.id !== ad2.id) {
      section.dataset.id = ad2.id;
      name.textContent = ad2.name;
      line.textContent = ad2.line;
      cta.textContent = ad2.cta;
      cta.href = ad2.url;
      if (ad2.image) {
        icon.textContent = "";
        icon.style.backgroundImage = `url(${JSON.stringify(ad2.image)})`;
      } else {
        icon.style.backgroundImage = "";
        icon.textContent = ad2.name.slice(0, 1).toUpperCase();
      }
    }
    remove.hidden = !upgradeUrl;
    if (upgradeUrl) void upgradeLink(upgradeUrl).then((href) => remove.href = href);
    paint();
    if (!timer) {
      lastTick = performance.now();
      timer = setInterval(tick, TICK_MS);
    }
  }
  close.addEventListener("click", async () => {
    await save();
    const done = adClosed(await read(), Date.now());
    if (done.due) return;
    const start = pending3;
    pending3 = void 0;
    state = done;
    render2();
    await chrome.storage.local.set({ [storageKeys.ads]: done });
    await start?.();
  });
  const observer = new MutationObserver(render2);
  for (const v of views) observer.observe(v, { attributes: true, attributeFilter: ["hidden"] });
  doc.addEventListener("visibilitychange", () => {
    lastTick = performance.now();
    if (doc.visibilityState === "hidden") void save();
  });
  chrome.storage.local.onChanged.addListener(async (changes) => {
    if (!(storageKeys.ads in changes) && !(storageKeys.adFeed in changes)) return;
    state = await read();
    render2();
  });
  void read().then((s) => {
    state = s;
    render2();
  });
  return {
    async gate(start) {
      const res = await sendCommand({ kind: "ad-gate" }).catch(() => void 0);
      if (!res?.ok || !res.ad) return start();
      pending3 = start;
      state = await read();
      render2();
    }
  };
}

// src/shared/asks.ts
var REVIEW_FIRST = 3;
var REVIEW_AGAIN = 5;
var SHARE_FIRST = 6;
var initialAskState = {
  saved: 0,
  reviewAsks: 0,
  reviewAt: REVIEW_FIRST,
  reviewDone: false,
  shareAt: SHARE_FIRST,
  shareDone: false
};
function answer(state, reply2) {
  const clear = (s, kind) => s.due === kind ? { ...s, due: void 0 } : s;
  switch (reply2) {
    case "rate":
    case "already-rated":
      return clear({ ...state, reviewDone: true }, "review");
    case "review-later":
      return clear({ ...state, reviewAt: state.saved + REVIEW_AGAIN }, "review");
    case "shared":
    case "share-dismissed":
      return clear({ ...state, shareDone: true }, "share");
  }
}
function offersAlreadyRated(state) {
  return state.reviewAsks > 1;
}
async function loadAsks() {
  const stored = (await chrome.storage.local.get(storageKeys.asks))[storageKeys.asks];
  return { ...initialAskState, ...stored };
}
var pending = Promise.resolve();
function updateAsks(change) {
  const next = pending.then(async () => {
    const state = change(await loadAsks());
    await chrome.storage.local.set({ [storageKeys.asks]: state });
    return state;
  });
  pending = next.catch(() => {
  });
  return next;
}
function storeUrl() {
  return `https://chromewebstore.google.com/detail/${chrome.runtime.id}`;
}
function reviewUrl() {
  return `${storeUrl()}/reviews`;
}

// design/icons/arrow.up.right.svg
var arrow_up_right_default = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M8 16 16.5 7.5M9.5 7.5h7v7"/></svg>\n';

// design/icons/arrow.down.circle.svg
var arrow_down_circle_default = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 7.5v8.5"/><path d="M8.5 12.75 12 16.25l3.5-3.5"/></svg>\n';

// design/icons/chevron.down.svg
var chevron_down_default = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m6 9.5 6 6 6-6"/></svg>\n';

// design/icons/checkmark.svg
var checkmark_default = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5.5 12.5 10 17l8.5-9.5"/></svg>\n';

// design/icons/doc.on.doc.svg
var doc_on_doc_default = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="8.5" y="8.5" width="11" height="12" rx="2.25"/><path d="M15.5 8.5V6.25A2.25 2.25 0 0 0 13.25 4h-6.5A2.25 2.25 0 0 0 4.5 6.25v8.5A2.25 2.25 0 0 0 6.75 17H8.5"/></svg>\n';

// design/icons/exclamationmark.triangle.svg
var exclamationmark_triangle_default = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M10.3 4.9a2 2 0 0 1 3.4 0l6.6 11.6a2 2 0 0 1-1.7 3H5.4a2 2 0 0 1-1.7-3z"/><path d="M12 9.5v4"/><circle cx="12" cy="16.6" r=".4" fill="currentColor"/></svg>\n';

// design/icons/folder.svg
var folder_default = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3.75 7.25c0-1.1.9-2 2-2h3.6l2 2.25h6.9c1.1 0 2 .9 2 2v7.75c0 1.1-.9 2-2 2H5.75c-1.1 0-2-.9-2-2z"/></svg>\n';

// design/icons/clock.svg
var clock_default = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 7v5.25l3.5 2"/></svg>\n';

// design/icons/gearshape.svg
var gearshape_default = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M10.3 3.9a1.7 1.7 0 0 1 3.4 0l.2 1.1a7.2 7.2 0 0 1 1.7 1l1.1-.4a1.7 1.7 0 0 1 2 .8l.1.2a1.7 1.7 0 0 1-.4 2.1l-.9.7a7.3 7.3 0 0 1 0 2l.9.7a1.7 1.7 0 0 1 .4 2.1l-.1.2a1.7 1.7 0 0 1-2 .8l-1.1-.4a7.2 7.2 0 0 1-1.7 1l-.2 1.1a1.7 1.7 0 0 1-3.4 0l-.2-1.1a7.2 7.2 0 0 1-1.7-1l-1.1.4a1.7 1.7 0 0 1-2-.8l-.1-.2a1.7 1.7 0 0 1 .4-2.1l.9-.7a7.3 7.3 0 0 1 0-2l-.9-.7a1.7 1.7 0 0 1-.4-2.1l.1-.2a1.7 1.7 0 0 1 2-.8l1.1.4a7.2 7.2 0 0 1 1.7-1z"/><circle cx="12" cy="12" r="2.75"/></svg>\n';

// design/icons/trash.svg
var trash_default = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4.5 6.5h15M9.5 6.5V5a1.5 1.5 0 0 1 1.5-1.5h2A1.5 1.5 0 0 1 14.5 5v1.5M6.5 6.5l.8 11.6a2 2 0 0 0 2 1.9h5.4a2 2 0 0 0 2-1.9l.8-11.6M10 10.5v6M14 10.5v6"/></svg>\n';

// design/icons/film.svg
var film_default = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="4" y="4.5" width="16" height="15" rx="2.25"/><path d="M8 4.5v15M16 4.5v15M4 9h4M4 15h4M16 9h4M16 15h4"/></svg>\n';

// design/icons/lock.svg
var lock_default = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="5.5" y="10.5" width="13" height="9.5" rx="2.25"/><path d="M8.5 10.5V8a3.5 3.5 0 0 1 7 0v2.5"/></svg>\n';

// design/icons/rectangle.inset.topright.filled.svg
var rectangle_inset_topright_filled_default = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3.25" y="4.75" width="17.5" height="14.5" rx="2.5"/><rect x="12.5" y="7.5" width="5.5" height="5" rx="1" fill="currentColor" stroke="none"/></svg>\n';

// design/icons/record.circle.svg
var record_circle_default = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="4.25" fill="currentColor" stroke="none"/></svg>\n';

// design/icons/sidebar.right.svg
var sidebar_right_default = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3.25" y="4.75" width="17.5" height="14.5" rx="2.5"/><path d="M14.75 4.75v14.5M17 8.5h1.25M17 11.5h1.25"/></svg>\n';

// design/icons/square.and.arrow.up.svg
var square_and_arrow_up_default = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 14V3.75M8.5 7.25 12 3.75l3.5 3.5M8.75 10h-1.5a2 2 0 0 0-2 2v6.25a2 2 0 0 0 2 2h9.5a2 2 0 0 0 2-2V12a2 2 0 0 0-2-2h-1.5"/></svg>\n';

// design/icons/star.svg
var star_default = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12.00 3.85L14.29 9.44L20.32 9.90L15.71 13.81L17.14 19.68L12.00 16.50L6.86 19.68L8.29 13.81L3.68 9.90L9.71 9.44Z"/></svg>\n';

// design/icons/stop.fill.svg
var stop_fill_default = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="6.5" y="6.5" width="11" height="11" rx="1.5" fill="currentColor" stroke="none"/></svg>\n';

// design/icons/waveform.svg
var waveform_default = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 12h1M7.5 9v6M11 5.5v13M14.5 8v8M18 10.5v3M20.5 12h-.5"/></svg>\n';

// design/icons/xmark.svg
var xmark_default = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M7 7l10 10M17 7 7 17"/></svg>\n';

// src/ui/icons.ts
var icons = {
  download: arrow_down_circle_default,
  copy: doc_on_doc_default,
  check: checkmark_default,
  chevronDown: chevron_down_default,
  close: xmark_default,
  lock: lock_default,
  record: record_circle_default,
  stop: stop_fill_default,
  warning: exclamationmark_triangle_default,
  film: film_default,
  folder: folder_default,
  gear: gearshape_default,
  clock: clock_default,
  sidePanel: sidebar_right_default,
  popup: rectangle_inset_topright_filled_default,
  trash: trash_default,
  external: arrow_up_right_default,
  star: star_default,
  share: square_and_arrow_up_default,
  waveform: waveform_default
};

// src/ui/asks-view.ts
var reply = (r) => updateAsks((s) => answer(s, r));
var COPIED_MS = 1200;
function openReview() {
  void reply("rate").finally(() => chrome.tabs.create({ url: reviewUrl() }));
}
async function copyLink(button2) {
  const idle = button2.innerHTML;
  await navigator.clipboard.writeText(storeUrl()).catch(() => {
  });
  button2.innerHTML = `${icons.check}<span>Copied</span>`;
  setTimeout(() => button2.innerHTML = idle, COPIED_MS);
  await reply("shared");
}
function button(label, quiet, onClick, icon = "") {
  const b = document.createElement("button");
  b.type = "button";
  b.className = `vz-btn vz-btn--small${quiet ? " vz-btn--quiet" : ""}`;
  b.innerHTML = `${icon}<span></span>`;
  b.querySelector("span").textContent = label;
  b.addEventListener("click", () => onClick(b));
  return b;
}
function bindAsk(root) {
  const card = root.querySelector("#ask");
  const edge = root.querySelector("#ask-edge");
  const title = root.querySelector("#ask-title");
  const text = root.querySelector("#ask-text");
  const actions = root.querySelector("#ask-actions");
  let shown;
  let linger = false;
  const render2 = (s) => {
    const key = s.due && `${s.due}:${s.reviewAsks}`;
    if (key === shown) return;
    shown = key;
    if (!s.due) {
      if (linger) setTimeout(() => card.hidden = !shown, COPIED_MS);
      else card.hidden = true;
      linger = false;
      return;
    }
    card.hidden = false;
    edge.textContent = `${s.saved} ${s.saved === 1 ? "file" : "files"} saved`;
    if (s.due === "review") {
      title.textContent = "Would you rate Vidzilla?";
      text.textContent = "A rating on the Chrome Web Store helps other people find it. It takes a minute.";
      actions.replaceChildren(
        button("Rate Vidzilla", false, openReview, icons.external),
        button("Not now", true, () => void reply("review-later")),
        ...offersAlreadyRated(s) ? [button("I already did", true, () => void reply("already-rated"))] : []
      );
    } else {
      title.textContent = "Know someone who saves videos?";
      text.textContent = "Send them Vidzilla. Copy the link to its Chrome Web Store page and paste it in a message.";
      const copy = button("Copy link", false, (b) => {
        if (linger) return;
        linger = true;
        void copyLink(b);
      }, icons.copy);
      actions.replaceChildren(copy, button("Not now", true, () => void reply("share-dismissed")));
    }
  };
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && storageKeys.asks in changes) void loadAsks().then(render2);
  });
  void loadAsks().then(render2);
}
function bindAskButtons(root) {
  const rate = root.querySelector("#rate");
  rate.innerHTML = `${icons.star}<span>Rate</span>`;
  rate.title = "Rate Vidzilla on the Chrome Web Store";
  rate.addEventListener("click", openReview);
  const share = root.querySelector("#share");
  share.innerHTML = `${icons.share}<span>Share</span>`;
  share.title = "Copy the link to Vidzilla on the Chrome Web Store, to send to a friend";
  let copying = false;
  share.addEventListener("click", () => {
    if (copying) return;
    copying = true;
    void copyLink(share);
    setTimeout(() => copying = false, COPIED_MS);
  });
}

// src/shared/history.ts
async function loadHistory() {
  return (await chrome.storage.local.get(storageKeys.history))[storageKeys.history] ?? [];
}
var pending2 = Promise.resolve();
async function removeHistory(id) {
  const list = id ? (await loadHistory()).filter((e) => e.id !== id) : [];
  await chrome.storage.local.set({ [storageKeys.history]: list });
}

// src/ui/history-view.ts
function hostOf(url) {
  try {
    return new URL(url).hostname.replace(/^www\./, "");
  } catch {
    return "";
  }
}
async function missingFiles(entries) {
  const ids = entries.flatMap((e) => e.chromeDownloadId === void 0 ? [] : [e.chromeDownloadId]);
  const found = await Promise.all(ids.map((id) => chrome.downloads.search({ id }).then(([d]) => [id, d])));
  return new Set(found.filter(([, d]) => !d || d.exists === false).map(([id]) => id));
}
function bindHistory(root) {
  const list = root.querySelector("#history");
  const empty = root.querySelector("#history-empty");
  const clear = root.querySelector("#clear-history");
  const rowTemplate = root.querySelector("#history-row");
  function row(e, missing) {
    const row2 = rowTemplate.content.firstElementChild.cloneNode(true);
    const thumb = row2.querySelector(".vz-thumb");
    if (e.thumbnail) thumb.style.backgroundImage = `url(${JSON.stringify(e.thumbnail)})`;
    else thumb.innerHTML = /\.(m4a|mp3|ogg|opus|flac|wav|aac|weba)$/i.test(e.filename) ? icons.waveform : icons.film;
    const file = row2.querySelector(".vz-history-file");
    file.textContent = e.filename;
    file.title = e.savedPath ?? e.filename;
    row2.querySelector(".vz-history-title").textContent = e.title || (e.filename.split("/").at(-1) ?? e.filename);
    const date = new Date(e.savedAt).toLocaleString(void 0, { dateStyle: "medium", timeStyle: "short" });
    row2.querySelector(".vz-history-meta").textContent = [hostOf(e.pageUrl), e.quality, e.bytes ? formatBytes(e.bytes) : "", date].filter(Boolean).join(" \xB7 ");
    const gone = e.chromeDownloadId !== void 0 && missing.has(e.chromeDownloadId);
    row2.classList.toggle("is-missing", gone);
    const show = row2.querySelector(".show");
    show.innerHTML = icons.folder;
    show.setAttribute("aria-label", show.title);
    show.disabled = gone || e.chromeDownloadId === void 0;
    if (gone) show.title = "The file was moved or deleted";
    show.addEventListener("click", () => e.chromeDownloadId !== void 0 && chrome.downloads.show(e.chromeDownloadId));
    const page = row2.querySelector(".page");
    page.innerHTML = icons.external;
    page.setAttribute("aria-label", page.title);
    if (/^https?:/.test(e.pageUrl)) page.href = e.pageUrl;
    else page.hidden = true;
    const remove = row2.querySelector(".remove");
    remove.innerHTML = icons.close;
    remove.setAttribute("aria-label", remove.title);
    remove.addEventListener("click", () => void removeHistory(e.id));
    return row2;
  }
  async function refresh() {
    const entries = await loadHistory();
    const missing = await missingFiles(entries);
    empty.hidden = entries.length > 0;
    clear.hidden = entries.length === 0;
    list.hidden = entries.length === 0;
    list.replaceChildren(...entries.map((e) => row(e, missing)));
  }
  clear.innerHTML = `${icons.trash}<span>Clear history</span>`;
  clear.addEventListener("click", () => void removeHistory());
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && changes[storageKeys.history]) void refresh();
  });
  void refresh();
}

// src/ui/ads-setting.ts
var DATE = new Intl.DateTimeFormat("en-GB", { day: "numeric", month: "long", year: "numeric" });
function bindAdsSetting(root) {
  const status = root.querySelector(".vz-ads-status");
  const action = root.querySelector(".vz-ads-action");
  const check = root.querySelector(".vz-ads-check");
  if (!status || !action || !check) return;
  let subscribed = false;
  let prices;
  let license;
  const render2 = () => {
    if (!license) return;
    const paid = isAdFree(license, Date.now());
    subscribed = paid && Boolean(license.until);
    const remove = prices ? `Remove them for ${prices.subscription} or ${prices.lifetime}.` : "Remove them with a small subscription or one payment.";
    if (!paid) status.textContent = `A short ad for one of our other apps before some downloads. ${remove}`;
    else if (license.until) status.textContent = `Off until ${DATE.format(license.until)}. Thanks for supporting Vidzilla.`;
    else status.textContent = "Off for good. Thanks for supporting Vidzilla.";
    action.textContent = paid ? "Manage" : "Remove ads";
    action.hidden = paid && !license.until;
    check.hidden = paid;
  };
  action.addEventListener("click", async () => {
    if (!subscribed) {
      await chrome.tabs.create({ url: await upgradeLink(UPGRADE_URL) });
      return;
    }
    action.disabled = true;
    try {
      const res = await fetch(PORTAL_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: await getInstallId() }),
        credentials: "omit"
      });
      const body = await res.json().catch(() => ({}));
      if (!res.ok || typeof body.url !== "string" || !body.url.startsWith("https://")) {
        throw new Error(typeof body.error === "string" ? body.error : "Couldn't open the billing page");
      }
      await chrome.tabs.create({ url: body.url });
    } catch (err) {
      status.textContent = `${err instanceof Error ? err.message : "Couldn't open the billing page"}. Try again, or write to support@followusai.com.`;
    } finally {
      action.disabled = false;
    }
  });
  check.addEventListener("click", async () => {
    check.disabled = true;
    check.textContent = "Checking";
    await sendCommand({ kind: "check-license" }).catch(() => {
    });
    check.textContent = "Check again";
    check.disabled = false;
  });
  const show = async () => {
    [license, prices] = await Promise.all([loadLicense(), loadPrices()]);
    render2();
  };
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && (storageKeys.license in changes || storageKeys.prices in changes)) void show();
  });
  void show().then(() => refreshPrices());
}

// src/ui/settings-form.ts
function bindSettingsForm(root) {
  const form = root.querySelector(".vz-settings-form");
  const example = root.querySelector(".vz-settings-example");
  const saved = root.querySelector(".vz-settings-saved");
  const field = (name) => form.elements.namedItem(name);
  let savedTimer;
  const readForm = () => {
    const maxLength = Math.round(Number(field("maxLength").value));
    return {
      template: field("template").value.trim() || defaultSettings.template,
      maxLength: Number.isFinite(maxLength) ? Math.min(200, Math.max(20, maxLength)) : defaultSettings.maxLength,
      subfolder: field("subfolder").value.trim(),
      saveAs: field("saveAs").checked,
      sidePanel: field("sidePanel").checked
    };
  };
  const showExample = (s) => {
    const name = buildFilename({
      template: s.template,
      maxLength: s.maxLength,
      title: "Northern Lights Over Troms\xF8",
      pageUrl: "https://www.example.com/watch",
      mediaUrl: "https://cdn.example.com/v/clip.mp4",
      ext: "mp4"
    });
    example.value = s.subfolder ? `${s.subfolder.replace(/[\\/]+$/, "")}/${name}` : name;
  };
  const fill = (s) => {
    const set = (name, value) => {
      const input = field(name);
      if (document.activeElement !== input) input.value = value;
    };
    set("template", s.template);
    set("maxLength", String(s.maxLength));
    set("subfolder", s.subfolder);
    field("saveAs").checked = s.saveAs;
    field("sidePanel").checked = s.sidePanel;
    showExample(s);
  };
  form.addEventListener("input", () => showExample(readForm()));
  form.addEventListener("submit", (e) => e.preventDefault());
  form.addEventListener("change", async () => {
    const s = readForm();
    showExample(s);
    await chrome.storage.local.set({ [storageKeys.settings]: s });
    saved.textContent = "Saved";
    clearTimeout(savedTimer);
    savedTimer = setTimeout(() => saved.textContent = "", 1500);
  });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && storageKeys.settings in changes) void loadSettings().then(fill);
  });
  void loadSettings().then(fill);
  bindAdsSetting(root);
}

// src/ui/popup.ts
var strip = document.getElementById("strip");
var pageHost = document.getElementById("page-host");
var template = document.getElementById("frame-template");
var isPanel = document.body.classList.contains("vz-popup--panel");
var settings = defaultSettings;
var tabId = -1;
var tab;
var jobs = {};
var ad;
var frames = /* @__PURE__ */ new Map();
var edited = /* @__PURE__ */ new Map();
var pendingErrors = /* @__PURE__ */ new Map();
var chosenVariant = /* @__PURE__ */ new Map();
var chosenSubtitle = /* @__PURE__ */ new Map();
var TYPE_ORDER = { dash: 0, hls: 1, http: 2, mse: 3 };
async function resolveTabId() {
  const params = new URLSearchParams(location.search);
  const param = params.get("tabId");
  if (param) {
    if (!params.has("narrow")) document.body.classList.add("wide");
    return Number(param);
  }
  const [active] = await chrome.tabs.query({ active: true, currentWindow: true });
  return active?.id ?? -1;
}
function sorted(media) {
  return [...media].sort(
    (a, b) => (a.rank ?? Infinity) - (b.rank ?? Infinity) || TYPE_ORDER[a.type] - TYPE_ORDER[b.type] || (b.sizeBytes ?? 0) - (a.sizeBytes ?? 0) || b.detectedAt - a.detectedAt
  );
}
function chosenStream(item) {
  if (item.type !== "hls" && item.type !== "dash") return void 0;
  return item.variants?.find((v) => v.id === chosenVariant.get(item.id)) ?? item.variants?.[0];
}
function defaultName(item) {
  return buildFilename({
    template: settings.template,
    maxLength: settings.maxLength,
    title: item.title ?? tab?.title,
    pageUrl: tab?.pageUrl ?? item.pageUrl,
    mediaUrl: item.url,
    serverFilename: item.serverFilename,
    ext: savedExt(item, chosenStream(item))
  });
}
function latestJob(mediaId) {
  return Object.values(jobs).filter((j) => j.mediaId === mediaId && j.tabId === tabId).sort((a, b) => b.startedAt - a.startedAt)[0];
}
function typeLabel(item) {
  if (item.type === "mse") return "PLAYER";
  return savedExt(item, chosenStream(item)).toUpperCase();
}
function renderEmpty() {
  strip.replaceChildren();
  frames.clear();
  const empty = document.createElement("div");
  empty.className = "vz-empty";
  empty.innerHTML = `${icons.film}<p class="vz-empty-title">No videos found yet</p><p>Start playing the video on this page, then open this again.</p>`;
  strip.append(empty);
}
function createFrame(item) {
  const frame = template.content.firstElementChild.cloneNode(true);
  frame.dataset.id = item.id;
  frame.querySelector(".copy").innerHTML = icons.copy;
  frame.querySelector(".download").innerHTML = icons.download;
  const name = frame.querySelector(".vz-frame-name");
  name.addEventListener("input", () => edited.set(item.id, name.value));
  for (const wrap of frame.querySelectorAll(".vz-select")) wrap.insertAdjacentHTML("beforeend", icons.chevronDown);
  const quality = frame.querySelector(".quality select");
  quality.addEventListener("change", () => {
    chosenVariant.set(item.id, quality.value);
    render();
  });
  const subtitles = frame.querySelector(".subtitles select");
  subtitles.addEventListener("change", () => chosenSubtitle.set(item.id, subtitles.value));
  frame.querySelector(".copy").addEventListener("click", async (e) => {
    const btn = e.currentTarget;
    await navigator.clipboard.writeText(item.url).catch(() => {
    });
    btn.innerHTML = icons.check;
    setTimeout(() => btn.innerHTML = icons.copy, 1200);
  });
  frame.querySelector(".download").addEventListener("click", async () => {
    pendingErrors.delete(item.id);
    const job = latestJob(item.id);
    if (job?.state === "running") {
      await sendCommand({ kind: job.recording ? "stop" : "cancel", payload: { jobId: job.jobId } });
      return;
    }
    const start = async () => {
      const res = await sendCommand({
        kind: "download",
        payload: { tabId, mediaId: item.id, filename: edited.get(item.id), variantId: chosenVariant.get(item.id), subtitleId: chosenSubtitle.get(item.id) || void 0 }
      });
      if (!res.ok) pendingErrors.set(item.id, res.error);
      render();
    };
    await (ad ? ad.gate(start) : start());
  });
  return frame;
}
function updateFrame(frame, item) {
  const thumb = frame.querySelector(".vz-thumb");
  const poster = item.thumbnail ?? tab?.thumbnail;
  const look = poster ?? (item.mime.startsWith("audio/") ? "waveform" : "film");
  if (thumb.dataset.look !== look) {
    thumb.dataset.look = look;
    thumb.style.backgroundImage = poster ? `url(${JSON.stringify(poster)})` : "";
    thumb.innerHTML = poster ? "" : item.mime.startsWith("audio/") ? icons.waveform : icons.film;
  }
  const name = frame.querySelector(".vz-frame-name");
  if (!edited.has(item.id) && document.activeElement !== name) name.value = defaultName(item);
  name.title = name.value;
  setText(frame.querySelector(".vz-badge"), typeLabel(item));
  const details = [
    item.isLive ? "Live" : formatDuration(item.durationSec),
    formatBytes(item.sizeBytes),
    new URL(item.url).hostname
  ].filter(Boolean);
  setText(frame.querySelector(".meta-text"), details.join(" \xB7 "));
  updateQuality(frame, item);
  updateSubtitles(frame, item);
  const note = document.createElement("p");
  const download = frame.querySelector(".download");
  const progress = frame.querySelector(".vz-perf");
  const job = latestJob(item.id);
  const isRunning = job?.state === "running";
  const mode = isRunning ? job.recording ? "stop" : "cancel" : item.isLive || item.type === "mse" ? "record" : "download";
  if (download.dataset.mode !== mode) {
    download.dataset.mode = mode;
    const look2 = {
      download: [icons.download, "Download"],
      record: [icons.record, "Record"],
      cancel: [icons.close, "Cancel"],
      stop: [icons.stop, "Stop and save"]
    };
    [download.innerHTML, download.title] = look2[mode];
    download.setAttribute("aria-label", download.title);
    download.classList.toggle("vz-icon-btn--primary", mode !== "cancel");
  }
  frame.classList.toggle("is-fogged", item.hasDrm);
  note.className = "vz-frame-note";
  let showProgress = false;
  let disabled = false;
  if (item.hasDrm) {
    disabled = true;
    note.innerHTML = `${icons.lock}<span>Protected by DRM. Not supported.</span>`;
  } else if (item.variants?.length === 0) {
    disabled = true;
    note.textContent = "No quality in this stream can be saved.";
  } else if (pendingErrors.has(item.id)) {
    note.classList.add("is-error");
    note.textContent = pendingErrors.get(item.id);
  } else if (job?.state === "running" && job.recording) {
    note.textContent = job.phase === "saving" ? "Saving the recording to your Downloads folder" : job.player?.armed ? "Reloading the page to record the video from the start" : item.type === "mse" ? `Recording what the player plays${job.bytesReceived ? ` \xB7 ${formatBytes(job.bytesReceived)}` : ""}. Stops when the video ends.` : `Recording ${formatDuration(job.recordedSec) || "0:00"}${job.bytesReceived ? ` \xB7 ${formatBytes(job.bytesReceived)}` : ""}`;
  } else if (job?.state === "running") {
    showProgress = true;
    const fraction = job.progress ?? (job.totalBytes ? job.bytesReceived / job.totalBytes : 0);
    progress.style.setProperty("--vz-perf-value", `${Math.min(100, fraction * 100)}%`);
    const quality = job.variantLabel ? ` ${job.variantLabel}` : "";
    if (job.phase === "saving") note.textContent = "Saving to your Downloads folder";
    else if (job.progress !== void 0)
      note.textContent = `Downloading${quality}, ${Math.floor(job.progress * 100)}%${job.bytesReceived ? ` \xB7 ${formatBytes(job.bytesReceived)}` : ""}`;
    else
      note.textContent = job.totalBytes ? `Downloading ${formatBytes(job.bytesReceived)} of ${formatBytes(job.totalBytes)}` : `Downloading ${formatBytes(job.bytesReceived)}`;
  } else if (job?.state === "complete") {
    note.classList.add(job.subtitleError ? "is-error" : "is-done");
    note.textContent = job.subtitleError ? `Saved as ${job.filename}, but the subtitles failed: ${job.subtitleError}. ` : `Saved as ${job.filename}${job.subtitleFile ? " with subtitles" : ""}. `;
    note.title = job.savedPath ?? job.filename;
    if (job.chromeDownloadId !== void 0) {
      note.classList.add("has-action");
      note.append(showInFolder(job.chromeDownloadId));
    }
  } else if (job?.state === "failed") {
    note.classList.add("is-error");
    note.textContent = `Download failed: ${job.error ?? "unknown error"}`;
  } else if (tab?.drmKeySystem && item.type !== "http") {
    note.innerHTML = `${icons.warning}<span></span>`;
    note.querySelector("span").textContent = `This page plays ${drmName(tab.drmKeySystem)}-protected video. If this is that stream, the saved file won't play.`;
  } else if (item.isLive) {
    note.textContent = "Live. Records until the stream ends or you press stop.";
  } else if (item.type === "mse") {
    note.textContent = "No file to fetch here. Record reloads the page and keeps what the player loads, from the start. Let the video play to the end.";
  } else {
    note.hidden = true;
  }
  download.disabled = disabled;
  progress.hidden = !showProgress;
  frame.classList.toggle("has-progress", showProgress);
  placeNote(frame.querySelector(".vz-frame-note"), note);
}
function setText(el, text) {
  if (el.textContent !== text) el.textContent = text;
}
function placeNote(current, next) {
  if (current.className !== next.className) current.className = next.className;
  current.hidden = next.hidden;
  current.title = next.title;
  if (current.innerHTML !== next.innerHTML) current.replaceChildren(...next.childNodes);
}
function showInFolder(downloadId) {
  const button2 = document.createElement("button");
  button2.type = "button";
  button2.className = "vz-text-btn";
  button2.textContent = "Show in folder";
  button2.dataset.download = String(downloadId);
  button2.addEventListener("click", () => chrome.downloads.show(downloadId));
  return button2;
}
function drmName(keySystem) {
  if (keySystem.includes("widevine")) return "Widevine";
  if (keySystem.includes("playready")) return "PlayReady";
  if (keySystem.includes("fps") || keySystem.includes("fairplay")) return "FairPlay";
  return "DRM";
}
function updateSubtitles(frame, item) {
  const wrap = frame.querySelector(".subtitles");
  const select = wrap.querySelector("select");
  const seen = /* @__PURE__ */ new Set();
  const tracks = [...item.subtitles ?? [], ...tab?.subtitles ?? []].filter((t) => {
    const key = (t.lang || t.label).toLowerCase();
    return !seen.has(key) && seen.add(key);
  });
  wrap.hidden = tracks.length === 0;
  if (wrap.hidden) return;
  const signature = tracks.map((t) => `${t.id}:${t.label}`).join("|");
  if (select.dataset.signature !== signature) {
    select.dataset.signature = signature;
    select.replaceChildren(new Option("No subtitles", ""), ...tracks.map((t) => new Option(`CC ${t.label}`, t.id)));
  }
  select.value = chosenSubtitle.get(item.id) ?? "";
  select.disabled = latestJob(item.id)?.state === "running" || item.hasDrm;
}
function updateQuality(frame, item) {
  const wrap = frame.querySelector(".quality");
  const select = wrap.querySelector("select");
  const variants = item.variants ?? [];
  wrap.hidden = variants.length < 2;
  if (wrap.hidden) return;
  const signature = variants.map((v) => `${v.id}:${v.label}`).join("|");
  if (select.dataset.signature !== signature) {
    select.dataset.signature = signature;
    select.replaceChildren(...variants.map((v) => new Option(v.label, v.id)));
  }
  select.value = chosenVariant.get(item.id) ?? variants[0].id;
  select.disabled = latestJob(item.id)?.state === "running" || item.hasDrm;
}
function render() {
  pageHost.textContent = tab?.pageUrl ? new URL(tab.pageUrl).hostname : "";
  const media = sorted(tab?.media ?? []);
  if (media.length === 0) {
    renderEmpty();
    return;
  }
  strip.querySelector(".vz-empty")?.remove();
  const keep = new Set(media.map((m) => m.id));
  for (const [id, el] of frames) {
    if (!keep.has(id)) {
      el.remove();
      frames.delete(id);
    }
  }
  let previous;
  for (const item of media) {
    let frame = frames.get(item.id);
    if (!frame) {
      frame = createFrame(item);
      frames.set(item.id, frame);
    }
    updateFrame(frame, item);
    const expected = previous ? previous.nextElementSibling : strip.firstElementChild;
    if (expected !== frame) {
      if (previous) previous.after(frame);
      else strip.prepend(frame);
    }
    previous = frame;
  }
}
async function load() {
  void sendCommand({ kind: "scan-tab", payload: { tabId } }).catch(() => {
  });
  const tabKey = storageKeys.tab(tabId);
  const data = await chrome.storage.session.get([tabKey, storageKeys.jobs]);
  tab = data[tabKey];
  jobs = data[storageKeys.jobs] ?? {};
  render();
}
async function switchTab(next) {
  if (next === tabId) return;
  tabId = next;
  for (const map of [edited, pendingErrors, chosenVariant, chosenSubtitle]) map.clear();
  strip.replaceChildren();
  frames.clear();
  await load();
}
var windowId;
var view = "videos";
function showView(next) {
  view = next;
  const open = next !== "videos";
  const button2 = document.querySelector("#toggle-settings");
  document.querySelector("#settings-view").hidden = next !== "settings";
  document.querySelector("#saved-view").hidden = next !== "saved";
  strip.hidden = open;
  document.querySelector(".vz-popup-foot").hidden = open;
  document.body.classList.toggle("has-view", open);
  button2.innerHTML = open ? icons.close : icons.gear;
  button2.title = open ? "Back to the videos" : "Settings";
  button2.setAttribute("aria-label", button2.title);
  button2.setAttribute("aria-controls", next === "saved" ? "saved-view" : "settings-view");
  button2.setAttribute("aria-expanded", String(open));
  document.querySelector("#open-history").setAttribute("aria-expanded", String(next === "saved"));
}
async function switchMode() {
  if (isPanel) {
    await setOpenMode(false);
    await chrome.action.openPopup().catch(() => {
    });
    if (windowId !== void 0 && typeof chrome.sidePanel.close === "function") await chrome.sidePanel.close({ windowId });
    else window.close();
    return;
  }
  if (windowId !== void 0) await chrome.sidePanel.open({ windowId });
  await setOpenMode(true);
  window.close();
}
function setupControls() {
  const settingsButton = document.querySelector("#toggle-settings");
  settingsButton.addEventListener("click", () => showView(view === "videos" ? "settings" : "videos"));
  showView("videos");
  bindSettingsForm(document);
  bindHistory(document);
  bindAskButtons(document);
  bindAsk(document);
  ad = bindAd(document);
  const mode = document.querySelector("#switch-mode");
  [mode.innerHTML, mode.title] = isPanel ? [icons.popup, "Switch to the popup"] : [icons.sidePanel, "Switch to the side panel"];
  mode.setAttribute("aria-label", mode.title);
  mode.hidden = document.body.classList.contains("wide");
  mode.addEventListener("click", () => void switchMode());
  const folder = document.querySelector("#open-folder");
  folder.innerHTML = `${icons.folder}<span>Downloads</span>`;
  folder.title = "Open your Downloads folder";
  folder.addEventListener("click", () => chrome.downloads.showDefaultFolder());
  const history = document.querySelector("#open-history");
  history.innerHTML = `${icons.clock}<span>Saved files</span>`;
  history.title = "Files Vidzilla saved, with Show in folder";
  history.addEventListener("click", () => showView("saved"));
  const clear = document.querySelector("#clear-list");
  clear.innerHTML = icons.trash;
  clear.addEventListener("click", () => void sendCommand({ kind: "clear-tab", payload: { tabId } }));
}
async function main() {
  setupControls();
  [tabId, settings, windowId] = await Promise.all([resolveTabId(), loadSettings(), chrome.windows.getCurrent().then((w) => w.id)]);
  if (isPanel) {
    if (!document.body.classList.contains("wide")) void setOpenMode(true);
    chrome.tabs.onActivated.addListener((info) => {
      if (info.windowId === windowId) void switchTab(info.tabId);
    });
  }
  chrome.storage.local.onChanged.addListener(async (changes) => {
    if (!(storageKeys.settings in changes)) return;
    settings = await loadSettings();
    render();
  });
  chrome.storage.session.onChanged.addListener((changes) => {
    const tabKey = storageKeys.tab(tabId);
    if (tabKey in changes) tab = changes[tabKey].newValue;
    if (storageKeys.jobs in changes) jobs = changes[storageKeys.jobs].newValue ?? {};
    if (tabKey in changes || storageKeys.jobs in changes) render();
  });
  await load();
}
void main();
//# sourceMappingURL=popup.js.map
