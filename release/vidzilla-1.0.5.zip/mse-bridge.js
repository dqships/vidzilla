"use strict";
(() => {
  // src/content/mse-bridge.ts
  var TAG = "__vidzilla_mse";
  var used = false;
  var port;
  var frame;
  var control = (type) => window.postMessage({ [TAG]: "control", type }, "*");
  window.addEventListener("message", (e) => {
    if (e.source !== window || e.data?.[TAG] !== true) return;
    const msg = e.data;
    if (msg.type === "mse-used" && !used) {
      used = true;
      chrome.runtime.sendMessage({ kind: "page-mse", payload: { mime: String(msg.mime ?? "").slice(0, 200) } }).then((res) => res?.jobId ? startCapture(res.jobId) : control("idle")).catch(() => control("idle"));
    } else if (msg.type === "mse-data" && port && msg.bytes instanceof ArrayBuffer) {
      port.postMessage({ type: "data", track: msg.track, mime: msg.mime, init: !!msg.init, offset: Number(msg.offset) || 0, bytes: msg.bytes }, [msg.bytes]);
    } else if (msg.type === "mse-ended" && port) {
      port.postMessage({ type: "ended" });
    }
  });
  function finish() {
    control("stop");
    port?.close();
    port = void 0;
    frame?.remove();
    frame = void 0;
  }
  function startCapture(jobId) {
    if (frame) return;
    const src = chrome.runtime.getURL("capture.html");
    frame = document.createElement("iframe");
    frame.src = src;
    frame.hidden = true;
    frame.setAttribute("aria-hidden", "true");
    frame.addEventListener("load", () => {
      const channel = new MessageChannel();
      port = channel.port1;
      port.onmessage = (e) => e.data?.type === "close" && finish();
      frame.contentWindow.postMessage({ vidzillaCapture: jobId }, `chrome-extension://${chrome.runtime.id}`, [channel.port2]);
      control("start");
    }, { once: true });
    (document.body ?? document.documentElement).append(frame);
  }
  chrome.runtime.onMessage.addListener((msg) => {
    if (!used) return;
    if (msg.kind === "mse-stop") {
      control("stop");
      port?.postMessage({ type: "stop" });
    } else if (msg.kind === "mse-cancel") {
      port?.postMessage({ type: "cancel" });
      finish();
    }
  });
})();
//# sourceMappingURL=mse-bridge.js.map
