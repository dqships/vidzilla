"use strict";
(() => {
  // src/content/mse-main.ts
  var sources = /* @__PURE__ */ new WeakMap();
  var fed = [];
  var END_SETTLE_MS = 4e3;
  var endTimer;
  function allEnded() {
    const live = fed.flatMap((r) => {
      const ms2 = r.deref();
      return ms2 ? [sources.get(ms2)] : [];
    });
    return live.length > 0 && live.every((s) => s.ended);
  }
  function checkEnded() {
    clearTimeout(endTimer);
    if (!allEnded()) return;
    endTimer = setTimeout(() => {
      if (!allEnded()) return;
      if (recording()) post({ type: "mse-ended" });
      else if (state === "undecided") endedEarly = true;
    }, END_SETTLE_MS);
  }
  var TAG = "__vidzilla_mse";
  var tracks = /* @__PURE__ */ new WeakMap();
  var buffers = [];
  var nextId = 1;
  var state = "undecided";
  var queue = [];
  var queued = 0;
  var MAX_QUEUED_BYTES = 64 * 1024 * 1024;
  var DECIDE_WITHIN_MS = 5e3;
  var recording = () => state === "recording";
  function idle() {
    state = "idle";
    queue = [];
    queued = 0;
  }
  var announced = false;
  var endedEarly = false;
  var post = (msg, transfer = []) => window.postMessage({ [TAG]: true, ...msg }, "*", transfer);
  function isInit(bytes) {
    if (bytes.length >= 8) {
      const box = String.fromCharCode(bytes[4], bytes[5], bytes[6], bytes[7]);
      if (box === "ftyp" || box === "moov") return true;
    }
    return bytes.length >= 4 && bytes[0] === 26 && bytes[1] === 69 && bytes[2] === 223 && bytes[3] === 163;
  }
  function copy(data) {
    const view = data instanceof ArrayBuffer ? new Uint8Array(data) : new Uint8Array(data.buffer, data.byteOffset, data.byteLength);
    return view.slice().buffer;
  }
  var ms = window.MediaSource ?? window.ManagedMediaSource;
  if (ms) {
    try {
      Object.defineProperty(ms, "canConstructInDedicatedWorker", { value: false, configurable: true });
    } catch {
    }
    const addSourceBuffer = ms.prototype.addSourceBuffer;
    ms.prototype.addSourceBuffer = function(mime) {
      const sb = addSourceBuffer.call(this, mime);
      try {
        buffers.push(new WeakRef(sb));
        if (!announced) {
          announced = true;
          post({ type: "mse-used", mime });
          setTimeout(() => state === "undecided" && idle(), DECIDE_WITHIN_MS);
        }
        tracks.set(sb, { id: nextId++, mime, source: this });
        if (!sources.has(this)) {
          sources.set(this, { media: false, ended: false });
          this.addEventListener("sourceended", () => {
            sources.get(this).ended = true;
            checkEnded();
          });
          this.addEventListener("sourceopen", () => sources.get(this).ended = false);
        }
      } catch {
      }
      return sb;
    };
    const appendBuffer = SourceBuffer.prototype.appendBuffer;
    SourceBuffer.prototype.appendBuffer = function(data) {
      try {
        const track = tracks.get(this);
        if (track) {
          const view = data instanceof ArrayBuffer ? new Uint8Array(data) : new Uint8Array(data.buffer, data.byteOffset, data.byteLength);
          const init = isInit(view);
          if (init) track.init = copy(data);
          else if (track.init) {
            const src = sources.get(track.source);
            if (src && !src.media) {
              src.media = true;
              fed.push(new WeakRef(track.source));
            }
          }
          if (state === "recording") {
            const bytes = copy(data);
            post({ type: "mse-data", track: track.id, mime: track.mime, init, offset: this.timestampOffset, bytes }, [bytes]);
          } else if (state === "undecided") {
            const bytes = copy(data);
            queue.push({ track: track.id, mime: track.mime, init, offset: this.timestampOffset, bytes });
            queued += bytes.byteLength;
            if (queued > MAX_QUEUED_BYTES) idle();
          }
        }
      } catch {
      }
      return appendBuffer.call(this, data);
    };
  }
  window.addEventListener("message", (e) => {
    if (e.source !== window || e.data?.[TAG] !== "control") return;
    if (e.data.type === "start" && state !== "recording") {
      if (state === "undecided") {
        for (const m of queue) post({ type: "mse-data", ...m }, [m.bytes]);
        if (endedEarly && allEnded()) setTimeout(() => post({ type: "mse-ended" }));
      } else {
        replayInits();
      }
      queue = [];
      queued = 0;
      state = "recording";
    } else if (e.data.type === "stop" || e.data.type === "idle") {
      idle();
    }
  });
  function replayInits() {
    for (const sb of knownBuffers()) {
      const track = tracks.get(sb);
      if (!track?.init) continue;
      const bytes = track.init.slice(0);
      post({ type: "mse-data", track: track.id, mime: track.mime, init: true, offset: sb.timestampOffset, bytes }, [bytes]);
    }
  }
  function knownBuffers() {
    return buffers.flatMap((r) => {
      const sb = r.deref();
      return sb ? [sb] : [];
    });
  }
})();
//# sourceMappingURL=mse-main.js.map
