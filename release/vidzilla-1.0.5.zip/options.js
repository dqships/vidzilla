// src/shared/messages.ts
var storageKeys = {
  tab: (tabId) => `tab:${tabId}`,
  jobs: "jobs",
  settings: "settings",
  history: "history",
  asks: "asks",
  /** House ad schedule state (shared/ads.ts AdState). */
  ads: "ads",
  /** The ad list last fetched from the website, with when. */
  adFeed: "adFeed",
  /** The ad-free license as the website last answered (shared/license.ts). */
  license: "license",
  /** This install's random ID, in chrome.storage.sync. */
  installId: "installId",
  /** When a copy on this Chrome profile last saw a paid license (ms), in chrome.storage.sync. */
  paidAt: "paidAt",
  /** The checkout that confirmed this profile's purchase, in chrome.storage.sync: sent with each check. */
  paidSession: "paidSession",
  /** What removing the ads costs this install, as the website last said (shared/license.ts). */
  prices: "prices",
  /** When this install's first save was reported to PostHog as `activated` (ms), in chrome.storage.sync (sw/analytics.ts). */
  activatedAt: "activatedAt",
  /** When this install was reported to PostHog as `signed_up` (ms), in chrome.storage.sync (sw/analytics.ts). */
  signedUpAt: "signedUpAt",
  /** True while a fresh install's `signed_up` still has to reach PostHog, in chrome.storage.local (sw/analytics.ts). */
  signUpPending: "signUpPending"
};
function sendCommand(cmd) {
  return chrome.runtime.sendMessage(cmd);
}

// src/shared/naming.ts
var RESERVED_WINDOWS = /^(con|prn|aux|nul|com[1-9]|lpt[1-9])$/i;
var MAX_BYTES = 200;
function siteLabel(url) {
  let host;
  try {
    host = new URL(url).hostname;
  } catch {
    return "";
  }
  if (/^[\d.]+$/.test(host) || host.includes(":") || host.startsWith("[")) return host;
  const parts = host.replace(/^www\d*\./, "").split(".");
  if (parts.length === 1) return parts[0] ?? "";
  const secondLevel = parts.at(-2) ?? "";
  const hasCompoundSuffix = parts.length >= 3 && (parts.at(-1) ?? "").length === 2 && /^(co|com|org|net|gov|ac|edu|ne|or)$/.test(secondLevel);
  return (hasCompoundSuffix ? parts.at(-3) : secondLevel) ?? "";
}
function stripExt(name) {
  return name.replace(/\.[a-z0-9]{1,5}$/i, "");
}
function nameFromUrl(url) {
  try {
    const last = new URL(url).pathname.split("/").filter(Boolean).at(-1) ?? "";
    return stripExt(decodeURIComponent(last));
  } catch {
    return "";
  }
}
function isoDate(d) {
  const pad = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}
function expandTemplate(template, vars) {
  return template.replace(/([\s_-]*)%([a-z]+)/gi, (whole, sep, key) => {
    const value = vars[key.toLowerCase()];
    if (value === void 0) return whole;
    return value === "" ? "" : sep + value;
  }).replace(/^[\s_-]+|[\s_-]+$/g, "");
}
function truncateBytes(s, maxBytes) {
  const enc = new TextEncoder();
  if (enc.encode(s).length <= maxBytes) return s;
  let out = "";
  for (const ch of s) {
    if (enc.encode(out + ch).length > maxBytes) break;
    out += ch;
  }
  return out;
}
function sanitizeFilename(raw, maxLength = 80) {
  let s = raw.normalize("NFC");
  s = s.replace(/[\u0000-\u001f\u007f]/g, " ");
  s = s.replace(/[<>:"/\\|?*]/g, " ");
  s = s.replace(/\s+/g, " ").replace(/-{2,}/g, "-");
  s = s.replace(/^[\s.]+/, "");
  s = Array.from(s).slice(0, maxLength).join("");
  s = truncateBytes(s, MAX_BYTES);
  s = s.replace(/[\s.]+$/, "");
  if (RESERVED_WINDOWS.test(s)) s += "_";
  return s || "untitled";
}
function buildFilename(input) {
  const title = input.title?.trim() || (input.serverFilename ? stripExt(input.serverFilename) : "") || nameFromUrl(input.mediaUrl);
  const base = expandTemplate(input.template, {
    title,
    hostname: siteLabel(input.pageUrl),
    date: isoDate(input.now ?? /* @__PURE__ */ new Date())
  });
  return `${sanitizeFilename(base, input.maxLength)}.${input.ext}`;
}

// src/shared/settings.ts
var defaultSettings = {
  template: "%title",
  maxLength: 80,
  subfolder: "",
  saveAs: false,
  sidePanel: false
};
async function loadSettings() {
  const stored = (await chrome.storage.local.get(storageKeys.settings))[storageKeys.settings];
  return { ...defaultSettings, ...stored };
}

// src/shared/license.ts
var SITE_ORIGIN = "https://vidzilla.followusai.com";
var UPGRADE_URL = `${SITE_ORIGIN}/upgrade`;
var LICENSE_URL = `${SITE_ORIGIN}/api/license`;
var PRICES_URL = `${SITE_ORIGIN}/api/prices`;
var PRICES_TTL_MS = 6 * 36e5;
var PORTAL_URL = `${SITE_ORIGIN}/api/portal`;
var LICENSE_TTL_MS = 24 * 36e5;
var PAID_ELSEWHERE_RETRY_MS = 10 * 6e4;
var PAID_ELSEWHERE_GRACE_MS = 24 * 36e5;
var noLicense = { adFree: false, checkedAt: 0 };
async function getInstallId() {
  const stored = (await chrome.storage.sync.get(storageKeys.installId))[storageKeys.installId];
  if (typeof stored === "string" && stored) return stored;
  const id = crypto.randomUUID();
  await chrome.storage.sync.set({ [storageKeys.installId]: id });
  return id;
}
async function loadLicense() {
  const stored = (await chrome.storage.local.get(storageKeys.license))[storageKeys.license];
  return { ...noLicense, ...stored };
}
async function upgradeLink(base = UPGRADE_URL) {
  return `${base}?id=${encodeURIComponent(await getInstallId())}`;
}
function isAdFree(license, now) {
  return license.adFree && (license.until == null || license.until > now);
}
function parsePrices(json, now) {
  const j = json && typeof json === "object" ? json : {};
  const ok = (v) => typeof v === "string" && v.length > 0 && v.length <= 40;
  return ok(j.subscription) && ok(j.lifetime) ? { subscription: j.subscription, lifetime: j.lifetime, fetchedAt: now } : void 0;
}
async function loadPrices() {
  return (await chrome.storage.local.get(storageKeys.prices))[storageKeys.prices];
}
async function refreshPrices(now = Date.now()) {
  const cached = await loadPrices();
  if (cached && now - cached.fetchedAt < PRICES_TTL_MS) return cached;
  try {
    const url = new URL(PRICES_URL);
    url.searchParams.set("id", await getInstallId());
    const res = await fetch(url, { credentials: "omit", signal: AbortSignal.timeout(5e3) });
    const fresh = res.ok ? parsePrices(await res.json(), now) : void 0;
    if (fresh) {
      await chrome.storage.local.set({ [storageKeys.prices]: fresh });
      return fresh;
    }
  } catch {
  }
  return cached;
}

// src/ui/ads-setting.ts
var DATE = new Intl.DateTimeFormat("en-GB", { day: "numeric", month: "long", year: "numeric" });
function bindAdsSetting(root) {
  const status = root.querySelector(".vz-ads-status");
  const action = root.querySelector(".vz-ads-action");
  const check = root.querySelector(".vz-ads-check");
  if (!status || !action || !check) return;
  let subscribed = false;
  let prices;
  let license;
  const render = () => {
    if (!license) return;
    const paid = isAdFree(license, Date.now());
    subscribed = paid && Boolean(license.until);
    const remove = prices ? `Remove them for ${prices.subscription} or ${prices.lifetime}.` : "Remove them with a small subscription or one payment.";
    if (!paid) status.textContent = `A short ad for one of our other apps before some downloads. ${remove}`;
    else if (license.until) status.textContent = `Off until ${DATE.format(license.until)}. Thanks for supporting Vidzilla.`;
    else status.textContent = "Off for good. Thanks for supporting Vidzilla.";
    action.textContent = paid ? "Manage" : "Remove ads";
    action.hidden = paid && !license.until;
    check.hidden = paid;
  };
  action.addEventListener("click", async () => {
    if (!subscribed) {
      await chrome.tabs.create({ url: await upgradeLink(UPGRADE_URL) });
      return;
    }
    action.disabled = true;
    try {
      const res = await fetch(PORTAL_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: await getInstallId() }),
        credentials: "omit"
      });
      const body = await res.json().catch(() => ({}));
      if (!res.ok || typeof body.url !== "string" || !body.url.startsWith("https://")) {
        throw new Error(typeof body.error === "string" ? body.error : "Couldn't open the billing page");
      }
      await chrome.tabs.create({ url: body.url });
    } catch (err) {
      status.textContent = `${err instanceof Error ? err.message : "Couldn't open the billing page"}. Try again, or write to support@followusai.com.`;
    } finally {
      action.disabled = false;
    }
  });
  check.addEventListener("click", async () => {
    check.disabled = true;
    check.textContent = "Checking";
    await sendCommand({ kind: "check-license" }).catch(() => {
    });
    check.textContent = "Check again";
    check.disabled = false;
  });
  const show = async () => {
    [license, prices] = await Promise.all([loadLicense(), loadPrices()]);
    render();
  };
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && (storageKeys.license in changes || storageKeys.prices in changes)) void show();
  });
  void show().then(() => refreshPrices());
}

// src/ui/settings-form.ts
function bindSettingsForm(root) {
  const form = root.querySelector(".vz-settings-form");
  const example = root.querySelector(".vz-settings-example");
  const saved = root.querySelector(".vz-settings-saved");
  const field = (name) => form.elements.namedItem(name);
  let savedTimer;
  const readForm = () => {
    const maxLength = Math.round(Number(field("maxLength").value));
    return {
      template: field("template").value.trim() || defaultSettings.template,
      maxLength: Number.isFinite(maxLength) ? Math.min(200, Math.max(20, maxLength)) : defaultSettings.maxLength,
      subfolder: field("subfolder").value.trim(),
      saveAs: field("saveAs").checked,
      sidePanel: field("sidePanel").checked
    };
  };
  const showExample = (s) => {
    const name = buildFilename({
      template: s.template,
      maxLength: s.maxLength,
      title: "Northern Lights Over Troms\xF8",
      pageUrl: "https://www.example.com/watch",
      mediaUrl: "https://cdn.example.com/v/clip.mp4",
      ext: "mp4"
    });
    example.value = s.subfolder ? `${s.subfolder.replace(/[\\/]+$/, "")}/${name}` : name;
  };
  const fill = (s) => {
    const set = (name, value) => {
      const input = field(name);
      if (document.activeElement !== input) input.value = value;
    };
    set("template", s.template);
    set("maxLength", String(s.maxLength));
    set("subfolder", s.subfolder);
    field("saveAs").checked = s.saveAs;
    field("sidePanel").checked = s.sidePanel;
    showExample(s);
  };
  form.addEventListener("input", () => showExample(readForm()));
  form.addEventListener("submit", (e) => e.preventDefault());
  form.addEventListener("change", async () => {
    const s = readForm();
    showExample(s);
    await chrome.storage.local.set({ [storageKeys.settings]: s });
    saved.textContent = "Saved";
    clearTimeout(savedTimer);
    savedTimer = setTimeout(() => saved.textContent = "", 1500);
  });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && storageKeys.settings in changes) void loadSettings().then(fill);
  });
  void loadSettings().then(fill);
  bindAdsSetting(root);
}

// src/ui/options.ts
bindSettingsForm(document);
//# sourceMappingURL=options.js.map
