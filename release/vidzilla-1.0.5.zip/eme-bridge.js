"use strict";
(() => {
  // src/content/eme-bridge.ts
  var reported;
  window.addEventListener("message", (e) => {
    if (e.source !== window || e.data?.__vidzilla !== "eme") return;
    const keySystem = String(e.data.keySystem ?? "unknown").slice(0, 100);
    if (keySystem === "org.w3.clearkey") return;
    if (reported && (reported !== "encrypted" || keySystem === "encrypted")) return;
    reported = keySystem;
    chrome.runtime.sendMessage({ kind: "page-drm", payload: { keySystem } }).catch(() => {
    });
  });
})();
//# sourceMappingURL=eme-bridge.js.map
